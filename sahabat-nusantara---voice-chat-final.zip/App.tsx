

import React, { useState, useEffect, useReducer, useCallback, useMemo } from 'react';
import type { AppStatus, User, Profile, Channel } from './types';
import { AppContext, appReducer, initialState, useAppContext } from './context/AppContext';
import WelcomeBackPage from './components/pages/WelcomeBackPage';
import LoginPage from './components/pages/LoginPage';
import ProfileSetupPage from './components/pages/ProfileSetupPage';
import MainAppPage from './components/main/MainAppPage';
import SettingsPanel from './components/modals/SettingsPanel';
import RoomChatOverlay from './components/modals/RoomChatOverlay';
import PrivateMessagesOverlay from './components/modals/PrivateMessagesOverlay';
import UserProfileModal from './components/modals/UserProfileModal';
import EditProfileModal from './components/modals/EditProfileModal';
import YoutubeModal from './components/modals/YoutubeModal';
import CoinModal from './components/modals/CoinModal';
import SawerModal from './components/modals/SawerModal';
import CreateRoomModal from './components/modals/CreateRoomModal';
import Toast from './components/ui/Toast';
import CoinAnimationLayer from './components/ui/CoinAnimationLayer';
import AdminLoginPage from './components/pages/AdminLoginPage';
import Modal from './components/ui/Modal';
import AdminUserActionsModal from './components/modals/AdminUserActionsModal';
import AdminMoveUserModal from './components/modals/AdminMoveUserModal';
import AdminEditUserModal from './components/modals/AdminEditUserModal';
import ConfirmationModal from './components/modals/ConfirmationModal';
import AdminPanel from './components/modals/AdminPanel';
import AdminEditChannelModal from './components/modals/AdminEditChannelModal';


const App: React.FC = () => {
    const [state, dispatch] = useReducer(appReducer, initialState);
    const [appStatus, setAppStatus] = useState<AppStatus>('loading');
    const [toastMessage, setToastMessage] = useState<string>('');
    const [coinAnimation, setCoinAnimation] = useState<{ key: number, from: string, to: string } | null>(null);

    const showToast = useCallback((message: string) => {
        setToastMessage(message);
        setTimeout(() => setToastMessage(''), 3000);
    }, []);
    
    const triggerCoinAnimation = useCallback((fromId: string, toId: string) => {
        setCoinAnimation({ key: Date.now(), from: fromId, to: toId });
    }, []);

    useEffect(() => {
        const loadInitialData = () => {
            const settingsData = localStorage.getItem('sahabatNusantaraSettings');
            if (settingsData) {
                dispatch({ type: 'SET_SETTINGS', payload: JSON.parse(settingsData) });
            }

            const currentUid = localStorage.getItem('sn_current_uid');
            if (currentUid) {
                const userProfileJson = localStorage.getItem(`sn_user_${currentUid}`);
                if (userProfileJson) {
                    const profile: Profile = JSON.parse(userProfileJson);
                    const user: User = { uid: currentUid, profile };
                    dispatch({ type: 'SET_CURRENT_USER', payload: user });
                    dispatch({ type: 'ADD_USER', payload: user });
                    setAppStatus('welcome-back');
                } else {
                    localStorage.removeItem('sn_current_uid');
                    setAppStatus('login');
                }
            } else {
                setAppStatus('login');
            }
        };

        // Simulate a short loading time
        const timer = setTimeout(loadInitialData, 500);
        return () => clearTimeout(timer);
    }, []);

    useEffect(() => {
        document.documentElement.classList.toggle('dark', state.settings.theme === 'dark');
        localStorage.setItem('sahabatNusantaraSettings', JSON.stringify(state.settings));
    }, [state.settings]);
    
     useEffect(() => {
        if (!state.currentUser && appStatus === 'main') {
            setAppStatus('login');
        }
    }, [state.currentUser, appStatus]);

    const renderPage = () => {
        switch (appStatus) {
            case 'loading':
                return (
                    <div className="page p-6 flex flex-col justify-center items-center h-full text-center bg-white dark:bg-gray-900">
                        <div className="loader"></div>
                        <p className="mt-4 text-gray-600 dark:text-gray-300">Memuat aplikasi...</p>
                    </div>
                );
            case 'welcome-back':
                return <WelcomeBackPage setAppStatus={setAppStatus} />;
            case 'login':
                return <LoginPage setAppStatus={setAppStatus} />;
            case 'admin-login':
                return <AdminLoginPage setAppStatus={setAppStatus} />;
            case 'profile-setup':
                return <ProfileSetupPage setAppStatus={setAppStatus} />;
            case 'main':
                return <MainAppPage />;
            default:
                return null;
        }
    };

    const contextValue = useMemo(() => ({
        state,
        dispatch,
        showToast,
        triggerCoinAnimation,
        setAppStatus
    }), [state, showToast, triggerCoinAnimation]);

    return (
        <AppContext.Provider value={contextValue}>
            <div id="app-container" className="max-w-md mx-auto shadow-lg overflow-hidden">
                <CoinAnimationLayer animationTrigger={coinAnimation} />
                {renderPage()}
                {appStatus === 'main' && (
                    <>
                        <SettingsPanel />
                        <RoomChatOverlay />
                        <PrivateMessagesOverlay />
                        <UserProfileModal />
                        <EditProfileModal />
                        <YoutubeModal />
                        <CoinModal />
                        <SawerModal />
                        <CreateRoomModal />
                        <AdminPanel />
                        <AdminEditUserModal />
                        <ConfirmationModal />
                        <AdminEditChannelModal />
                        <AdminUserActionsModal />
                        <AdminMoveUserModal />
                    </>
                )}
                <Toast message={toastMessage} />
            </div>
        </AppContext.Provider>
    );
};

export default App;