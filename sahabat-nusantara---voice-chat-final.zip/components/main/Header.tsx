
import React from 'react';
import { useAppContext } from '../../context/AppContext';

const Header: React.FC = () => {
    const { dispatch } = useAppContext();

    const openSettings = () => {
        dispatch({ type: 'SHOW_MODAL', payload: { type: 'settings' } });
    };

    return (
        <header className="bg-green-700 text-white p-4 flex items-center justify-between shadow-md z-10 flex-shrink-0">
            <button onClick={openSettings} className="nav-button p-2 rounded-full" aria-label="Buka Pengaturan">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
            </button>
            <div className="text-center">
                <h1 className="text-xl font-bold tracking-wider header-title">SAHABAT NUSANTARA</h1>
                <p className="text-xs font-light opacity-80">Wadah Komunikasi Modern</p>
            </div>
            <div className="w-10 h-10"></div> {/* Placeholder to balance title */}
        </header>
    );
};

export default Header;
