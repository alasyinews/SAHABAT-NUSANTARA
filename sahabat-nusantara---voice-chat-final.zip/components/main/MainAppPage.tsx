

import React, { useEffect, useState, useRef, useMemo } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from "@google/genai";
import Header from './Header';
import Navbar from './Navbar';
import RoomSwiper from './RoomSwiper';
import PttButton from './PttButton';
import SawerButton from './SawerButton';
import { useAppContext } from '../../context/AppContext';
import { decode, decodeAudioData, createBlob, resampleBuffer } from '../../utils/helpers';
import type { Message } from '../../types';
import { AI_USER } from '../../constants';

const MainAppPage: React.FC = () => {
    const { state, dispatch, showToast } = useAppContext();
    const { currentPresence, currentChannelIndex, channels } = state;
    const [isMicPermissionGranted, setIsMicPermissionGranted] = useState(false);
    
    const isTalkingRef = useRef(false);
    const isMutedRef = useRef(false);
    const isDeafenedRef = useRef(false);

    const sessionPromiseRef = useRef<Promise<any> | null>(null);
    const audioRefs = useRef<{
        inputAudioContext?: AudioContext;
        outputAudioContext?: AudioContext;
        sources?: Set<AudioBufferSourceNode>;
        nextStartTime?: number;
        scriptProcessor?: ScriptProcessorNode;
        mediaStreamSource?: MediaStreamAudioSourceNode;
        outputNode?: GainNode;
    }>({});
    
    useEffect(() => {
        isTalkingRef.current = currentPresence?.isTalking || false;
        isMutedRef.current = currentPresence?.isMicMuted || false;
        isDeafenedRef.current = currentPresence?.isDeafened || false;
    }, [currentPresence]);

    useEffect(() => {
        const audioCtx = audioRefs.current.outputAudioContext;
        const gainNode = audioRefs.current.outputNode;
        if (audioCtx && gainNode) {
            const targetGain = isDeafenedRef.current ? 0 : 1;
            gainNode.gain.setValueAtTime(targetGain, audioCtx.currentTime);
        }
    }, [currentPresence?.isDeafened]);


    useEffect(() => {
        const currentChannel = channels[currentChannelIndex];
        if (!currentChannel || !isMicPermissionGranted) {
            return;
        }

        dispatch({
            type: 'UPDATE_USER_PRESENCE',
            payload: { uid: AI_USER.uid, channelId: currentChannel.id }
        });

        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        
        const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        audioRefs.current.outputAudioContext = outputAudioContext;
        
        const outputNode = outputAudioContext.createGain();
        audioRefs.current.outputNode = outputNode;
        outputNode.connect(outputAudioContext.destination);

        const convolver = outputAudioContext.createConvolver();
        const wetGain = outputAudioContext.createGain();
        const dryGain = outputAudioContext.createGain();

        const impulseLength = outputAudioContext.sampleRate * 2;
        const impulse = outputAudioContext.createBuffer(2, impulseLength, outputAudioContext.sampleRate);
        const impulseL = impulse.getChannelData(0);
        const impulseR = impulse.getChannelData(1);
        for (let i = 0; i < impulseLength; i++) {
            const val = (Math.random() * 2 - 1) * Math.pow(1 - i / impulseLength, 2.5);
            impulseL[i] = val;
            impulseR[i] = val;
        }
        convolver.buffer = impulse;
        
        wetGain.connect(convolver);
        convolver.connect(outputNode);
        dryGain.connect(outputNode);

        audioRefs.current.sources = new Set();
        audioRefs.current.nextStartTime = 0;
        
        const sessionPromise = ai.live.connect({
            model: 'gemini-2.5-flash-native-audio-preview-09-2025',
            callbacks: {
                onopen: () => {
                   console.log('Live session opened.');
                },
                onmessage: async (message: LiveServerMessage) => {
                    const mode = channels[state.currentChannelIndex]?.mode;
                     if (mode === 'karaoke-reverb') {
                        wetGain.gain.setValueAtTime(0.6, outputAudioContext.currentTime);
                        dryGain.gain.setValueAtTime(0.4, outputAudioContext.currentTime);
                    } else {
                        wetGain.gain.setValueAtTime(0, outputAudioContext.currentTime);
                        dryGain.gain.setValueAtTime(1, outputAudioContext.currentTime);
                    }

                    const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
                    if (base64Audio && audioRefs.current.outputAudioContext && audioRefs.current.sources) {
                        if (audioRefs.current.sources.size === 0) {
                            dispatch({ type: 'UPDATE_USER_PRESENCE', payload: { uid: AI_USER.uid, isTalking: true } });
                        }
                        
                        const outputCtx = audioRefs.current.outputAudioContext;
                        audioRefs.current.nextStartTime = Math.max(audioRefs.current.nextStartTime ?? 0, outputCtx.currentTime);
                        
                        const audioBuffer = await decodeAudioData(decode(base64Audio), outputCtx, 24000, 1);
                        const source = outputCtx.createBufferSource();
                        source.buffer = audioBuffer;
                        source.connect(dryGain);
                        source.connect(wetGain);
                        source.addEventListener('ended', () => {
                            audioRefs.current.sources?.delete(source);
                            if (audioRefs.current.sources?.size === 0) {
                                dispatch({ type: 'UPDATE_USER_PRESENCE', payload: { uid: AI_USER.uid, isTalking: false } });
                            }
                        });
                        source.start(audioRefs.current.nextStartTime);
                        audioRefs.current.nextStartTime += audioBuffer.duration;
                        audioRefs.current.sources.add(source);
                    }

                    if (message.serverContent?.outputTranscription) {
                        const text = message.serverContent.outputTranscription.text;
                        if (text.trim() && message.serverContent.turnComplete) {
                            const aiMessage: Message = {
                                id: `ai-msg-${Date.now()}`,
                                senderId: AI_USER.uid,
                                text: text.trim(),
                                timestamp: new Date().toISOString(),
                            };
                            dispatch({ type: 'ADD_PUBLIC_MESSAGE', payload: { channelId: currentChannel.id, message: aiMessage } });
                        }
                    }
                },
                onerror: (e: ErrorEvent) => {
                    console.error('Live session error:', e);
                    showToast('Koneksi suara bermasalah.');
                },
                onclose: (e: CloseEvent) => {
                    console.log('Live session closed.');
                },
            },
            config: {
                responseModalities: [Modality.AUDIO],
                outputAudioTranscription: {},
                systemInstruction: `You are Sahabat AI, a friendly and helpful assistant in this voice chat room named "${currentChannel.name}". Keep your responses concise, engaging, and in Indonesian.`,
            },
        });
        sessionPromiseRef.current = sessionPromise;

        sessionPromise.catch(e => {
            if (e.name !== 'Canceled' && e.message !== 'Canceled') {
                console.error('Live session connection failed:', e);
                showToast('Koneksi suara gagal.');
            }
        });


        return () => {
            sessionPromise.then(session => session.close()).catch(e => {
                if (e.name !== 'Canceled' && e.message !== 'Canceled') {
                    console.error("Error closing session during cleanup:", e);
                }
            });
            sessionPromiseRef.current = null;
            audioRefs.current.outputAudioContext?.close();
        };

    }, [currentChannelIndex, channels, isMicPermissionGranted, dispatch, showToast, state.currentChannelIndex]);


    useEffect(() => {
        const initMic = async () => {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                setIsMicPermissionGranted(true);
                
                const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
                const scriptProcessor = inputAudioContext.createScriptProcessor(4096, 1, 1);
                
                scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                    if (isTalkingRef.current && !isMutedRef.current) {
                        const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                        const resampledData = resampleBuffer(inputData, inputAudioContext.sampleRate, 16000);
                        const pcmBlob = createBlob(resampledData);

                        if (sessionPromiseRef.current) {
                           sessionPromiseRef.current.then((session) => {
                             session.sendRealtimeInput({ media: pcmBlob });
                           }).catch(e => { /* ignore cancellation */ });
                        }
                    }
                };

                const mediaStreamSource = inputAudioContext.createMediaStreamSource(stream);
                mediaStreamSource.connect(scriptProcessor);

                audioRefs.current.inputAudioContext = inputAudioContext;
                audioRefs.current.scriptProcessor = scriptProcessor;
                audioRefs.current.mediaStreamSource = mediaStreamSource;

            } catch (err) {
                console.error('Error accessing microphone:', err);
                setIsMicPermissionGranted(false);
                showToast('Izin mikrofon ditolak.');
            }
        };

        initMic();

        return () => {
            audioRefs.current.scriptProcessor?.disconnect();
            audioRefs.current.mediaStreamSource?.disconnect();
            audioRefs.current.inputAudioContext?.close();
        };
    }, [showToast]);

    return (
        <div className="page flex flex-col h-full overflow-hidden">
            <Header />
            <Navbar />
            <div className="flex-grow relative" style={{ minHeight: 0 }}>
                <RoomSwiper />
                <SawerButton />
            </div>
            <footer id="app-footer" className="p-4 bg-white border-t border-gray-200 dark:border-gray-700 relative">
                 <div className="h-[var(--ptt-h)] flex items-center justify-center">
                    {currentPresence?.isMicMuted || currentPresence?.isDeafened ? (
                        <div className="text-center">
                            <p className="font-semibold text-red-500">
                                {currentPresence.isDeafened ? 'ANDA TULI & BISU' : 'ANDA BISU'}
                            </p>
                            <p className="text-xs text-gray-500">
                                {currentPresence.isDeafened ? 'Nonaktifkan mode tuli untuk berbicara.' : 'Nonaktifkan mode bisu untuk berbicara.'}
                            </p>
                        </div>
                    ) : (
                         <div className={!isMicPermissionGranted ? 'opacity-50 pointer-events-none w-full' : 'w-full'}>
                            <PttButton />
                         </div>
                    )}
                 </div>
                 {!isMicPermissionGranted && <p className="text-xs text-center text-red-500 absolute bottom-0.5 left-0 right-0">Izin mikrofon diperlukan untuk berbicara.</p>}
            </footer>
        </div>
    );
};

export default MainAppPage;