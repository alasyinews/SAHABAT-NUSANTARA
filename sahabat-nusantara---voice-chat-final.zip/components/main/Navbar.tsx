import React, { useMemo } from 'react';
import { useAppContext } from '../../context/AppContext';
import { ICONS } from '../../constants';

const Navbar: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { currentPresence, channels, currentChannelIndex, currentUser, isAdmin } = state;
    const currentChannel = channels[currentChannelIndex];
    
    const canChangeMode = useMemo(() => {
        if (!currentUser || !currentChannel) return false;
        const profile = currentUser.profile;
        if (isAdmin) return true;

        const canChangeRoomModePermission = profile.moderatorPermissions?.canChangeRoomMode;
        if (!canChangeRoomModePermission) return false;

        if (profile.moderatorRole === 'global') return true;
        if (profile.moderatorRole === 'room' && profile.managedChannelId === currentChannel.id) {
            return true;
        }
        return false;
    }, [currentUser, currentChannel, isAdmin]);

    const handleMicToggle = () => {
        if (!currentPresence) return;
        const isMuted = !currentPresence.isMicMuted;
        dispatch({
            type: 'UPDATE_USER_PRESENCE',
            payload: { uid: currentPresence.uid, isMicMuted: isMuted, isDeafened: isMuted ? false : currentPresence.isDeafened }
        });
    };

    const handleDeafenToggle = () => {
        if (!currentPresence) return;
        const isDeafened = !currentPresence.isDeafened;
        dispatch({
            type: 'UPDATE_USER_PRESENCE',
            payload: { uid: currentPresence.uid, isDeafened: isDeafened, isMicMuted: isDeafened ? true : currentPresence.isMicMuted }
        });
    };
    
    const handleModeToggle = () => {
        if (!canChangeMode || !currentChannel) return;
        let nextMode: 'talk' | 'karaoke' | 'karaoke-reverb';
        switch (currentChannel.mode) {
            case 'talk':
                nextMode = 'karaoke';
                break;
            case 'karaoke':
                nextMode = 'karaoke-reverb';
                break;
            case 'karaoke-reverb':
            default:
                nextMode = 'talk';
                break;
        }

        dispatch({
            type: 'SET_CHANNEL_MODE',
            payload: { channelId: currentChannel.id, mode: nextMode }
        });
    };

    const modeIcon = () => {
        if (!currentChannel) return '';
        
        switch (currentChannel.mode) {
            case 'talk':
                return `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path></svg>`;
            case 'karaoke':
                return `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19V6l10-3v13l-10 3zM9 6H5a2 2 0 00-2 2v8a2 2 0 002 2h4"></path></svg>`;
            case 'karaoke-reverb':
                return `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19V6l10-3v13l-10 3zM9 6H5a2 2 0 00-2 2v8a2 2 0 002 2h4"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20.5 8a5 5 0 010 8" opacity="0.8"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M22.5 6a9 9 0 010 12" opacity="0.5"></path></svg>`;
            default:
                return '';
        }
    };
    
    const getModeButtonTooltip = () => {
        if (!currentChannel) return "Ganti Mode";
        switch (currentChannel.mode) {
            case 'talk': return "Mode Suara Aktif";
            case 'karaoke': return "Mode Karaoke Aktif";
            case 'karaoke-reverb': return "Mode Karaoke Reverb Aktif";
            default: return "Ganti Mode";
        }
    };
    
    return (
        <nav className="bg-green-800 text-white p-2 flex justify-around items-center shadow-inner flex-shrink-0">
            <button onClick={() => dispatch({type: 'SHOW_MODAL', payload: {type: 'room-chat'}})} className="nav-button p-2 rounded-full" aria-label="Buka Obrolan Room">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a2 2 0 01-2-2V10a2 2 0 012-2h8z"></path></svg>
            </button>
            <button onClick={() => dispatch({type: 'SHOW_MODAL', payload: {type: 'private-messages'}})} className="nav-button p-2 rounded-full" aria-label="Buka Pesan Pribadi">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
            </button>
            <button onClick={() => dispatch({type: 'SHOW_MODAL', payload: {type: 'youtube'}})} className="nav-button p-2 rounded-full" aria-label="Buka Karaoke YouTube">
                <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor"><path d="M21.582,6.186c-0.23-0.86-0.908-1.538-1.768-1.768C18.267,4,12,4,12,4S5.733,4,4.186,4.418 c-0.86,0.23-1.538,0.908-1.768,1.768C2,7.733,2,12,2,12s0,4.267,0.418,5.814c0.23,0.86,0.908,1.538,1.768,1.768 C5.733,20,12,20,12,20s6.267,0,7.814-0.418c0.861-0.23,1.538-0.908,1.768-1.768C22,16.267,22,12,22,12S22,7.733,21.582,6.186z M10,15.464V8.536L16,12L10,15.464z" /></svg>
            </button>
            <button
                onClick={handleModeToggle}
                className={`nav-button p-2 rounded-full ${currentChannel?.mode === 'karaoke-reverb' ? 'muted' : ''}`}
                aria-label={getModeButtonTooltip()}
                title={canChangeMode ? getModeButtonTooltip() : "Hanya admin/moderator yang bisa mengubah mode"}
                dangerouslySetInnerHTML={{ __html: modeIcon() }}
                disabled={!canChangeMode}
            ></button>
            <button onClick={() => dispatch({type: 'SHOW_MODAL', payload: {type: 'coin'}})} className="nav-button p-2 rounded-full" aria-label="Buka Ruang Koin">
                 <svg className="w-6 h-6" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><defs><radialGradient id="coinGradientNav" cx="50%" cy="50%" r="50%" fx="25%" fy="25%"><stop offset="0%" stopColor="#FDE047"/><stop offset="100%" stopColor="#F59E0B"/></radialGradient></defs><circle cx="10" cy="10" r="9" fill="url(#coinGradientNav)"/><circle cx="10" cy="10" r="9" fill="transparent" stroke="#B45309" strokeWidth="1.2"/><path d="M10 5.5C10.5523 5.5 11 5.94772 11 6.5V13.5C11 14.0523 10.5523 14.5 10 14.5C9.44772 14.5 9 14.0523 9 13.5V6.5C9 5.94772 9.44772 5.5 10 5.5Z" fill="#FBBF24" fillOpacity="0.8"/><path d="M12.5 7.5C13.0523 7.5 13.5 7.94772 13.5 8.5V11.5C13.5 12.0523 13.0523 12.5 12.5 12.5C11.9477 12.5 11.5 12.0523 11.5 11.5V8.5C11.5 7.94772 11.9477 7.5 12.5 7.5Z" fill="#FBBF24" fillOpacity="0.8"/><path d="M7.5 7.5C8.05228 7.5 8.5 7.94772 8.5 8.5V11.5C8.5 12.0523 8.05228 12.5 7.5 12.5C6.94772 12.5 6.5 12.0523 6.5 11.5V8.5C6.5 7.94772 6.94772 7.5 7.5 7.5Z" fill="#FBBF24" fillOpacity="0.8"/></svg>
            </button>
            <button onClick={handleMicToggle} className={`nav-button p-2 rounded-full ${currentPresence?.isMicMuted ? 'muted' : ''}`} dangerouslySetInnerHTML={{ __html: currentPresence?.isMicMuted ? ICONS.micOff : ICONS.micOn }}></button>
            <button onClick={handleDeafenToggle} className={`nav-button p-2 rounded-full ${currentPresence?.isDeafened ? 'muted' : ''}`} dangerouslySetInnerHTML={{ __html: currentPresence?.isDeafened ? ICONS.speakerOff : ICONS.speakerOn }}></button>
        </nav>
    );
};

export default Navbar;