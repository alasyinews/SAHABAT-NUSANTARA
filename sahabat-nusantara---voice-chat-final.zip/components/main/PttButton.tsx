
import React from 'react';
import { useAppContext } from '../../context/AppContext';

const PttButton: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { settings, currentPresence } = state;

    const isPttOn = currentPresence?.isTalking || false;

    const handlePttStateChange = (isActive: boolean) => {
        if (!currentPresence || currentPresence.isTalking === isActive) return;

        dispatch({
            type: 'UPDATE_USER_PRESENCE',
            payload: { uid: currentPresence.uid, isTalking: isActive },
        });
        
        try {
            const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
            if (audioCtx) {
                const oscillator = audioCtx.createOscillator();
                oscillator.type = 'triangle';
                oscillator.frequency.setValueAtTime(isActive ? 880 : 440, audioCtx.currentTime);
                oscillator.connect(audioCtx.destination);
                oscillator.start();
                oscillator.stop(audioCtx.currentTime + 0.1);
            }
        } catch (e) {
            console.warn("Web Audio API could not be initialized.", e);
        }
    };

    const handleToggleClick = () => {
        if (settings.pttMode === 'toggle') {
            handlePttStateChange(!isPttOn);
        }
    };

    const handlePushDown = (e: React.MouseEvent | React.TouchEvent) => {
        e.preventDefault();
        if (settings.pttMode === 'push') {
            handlePttStateChange(true);
        }
    };

    const handlePushUp = () => {
        if (settings.pttMode === 'push') {
            handlePttStateChange(false);
        }
    };

    return (
        <div
            id="ptt-button"
            className={`${isPttOn ? 'is-on' : 'is-off'}`}
            onClick={handleToggleClick}
            onMouseDown={handlePushDown}
            onMouseUp={handlePushUp}
            onMouseLeave={handlePushUp}
            onTouchStart={handlePushDown}
            onTouchEnd={handlePushUp}
            role="button"
            aria-pressed={isPttOn}
            tabIndex={0}
        >
            <div id="ptt-knob"></div>
            <span id="ptt-text">
                {isPttOn ? 'PTT SN ON' : 'PTT SN OFF'}
            </span>
        </div>
    );
};

export default PttButton;