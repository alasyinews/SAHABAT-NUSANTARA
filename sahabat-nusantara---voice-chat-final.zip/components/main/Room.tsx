import React, { useMemo, useState, useEffect, useCallback, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import type { Channel } from '../../types';
import { useAppContext } from '../../context/AppContext';
import UserBox from './UserBox';

interface RoomProps {
    channel: Channel;
}

const SuggestionText: React.FC<{ children: React.ReactNode, isLoading?: boolean }> = ({ children, isLoading }) => {
    const { state: { settings } } = useAppContext();
    const style: React.CSSProperties = {
        color: settings.theme === 'dark' ? '#e2e8f0' : '#1c1917',
        textShadow: settings.theme === 'dark' ? 'none' : '0 1px 1px rgba(255,255,255,0.4)',
    };
    return <p className={`px-4 text-center text-sm font-semibold ${isLoading ? 'animate-pulse' : ''}`} style={style}>{children}</p>;
};


const Room: React.FC<RoomProps> = ({ channel }) => {
    const { state } = useAppContext();
    const [suggestion, setSuggestion] = useState('');
    const [isLoadingSuggestion, setIsLoadingSuggestion] = useState(false);
    const suggestionTimerRef = useRef<number | null>(null);

    const usersInChannel = useMemo(() => {
        return Object.values(state.presences)
            .filter(p => p.channelId === channel.id && p.isOnline && state.users[p.uid] && state.users[p.uid].profile)
            .map(p => ({ ...state.users[p.uid], presence: p }));
    }, [state.presences, state.users, channel.id]);
    
    const talkingUser = useMemo(() => usersInChannel.find(u => u.presence.isTalking), [usersInChannel]);

    const otherUsers = useMemo(() => {
        return usersInChannel
            .filter(u => !u.presence.isTalking)
            .sort((a, b) => {
                if (a.profile.isVip && !b.profile.isVip) return -1;
                if (!a.profile.isVip && b.profile.isVip) return 1;
                return (b.profile.coins || 0) - (a.profile.coins || 0);
            });
    }, [usersInChannel]);

    const generateSuggestion = useCallback(async () => {
        if (isLoadingSuggestion || talkingUser) return;

        setIsLoadingSuggestion(true);
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const prompt = `Buatkan satu topik pembuka percakapan yang menarik dan singkat untuk sebuah voice chat room bernama "${channel.name}". Topiknya harus relevan dengan nama room, santai, dan dalam Bahasa Indonesia. Langsung berikan kalimat topiknya saja tanpa embel-embel atau formatting. Contoh: "Kalau bisa punya kekuatan super, kalian pilih apa?"`;
            
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: prompt,
            });

            setSuggestion(response.text.trim());
        } catch (error) {
            console.error("Error generating suggestion:", error);
        } finally {
            setIsLoadingSuggestion(false);
        }
    }, [channel.name, isLoadingSuggestion, talkingUser]);

    useEffect(() => {
        if (suggestionTimerRef.current) {
            clearTimeout(suggestionTimerRef.current);
        }

        if (!talkingUser) {
            if (!suggestion) {
                generateSuggestion();
            }
            suggestionTimerRef.current = window.setTimeout(() => {
                generateSuggestion();
            }, 30000); 
        } else {
            setSuggestion('');
        }

        return () => {
            if (suggestionTimerRef.current) {
                clearTimeout(suggestionTimerRef.current);
            }
        };
    }, [talkingUser, generateSuggestion, suggestion]);

    const userListClass = usersInChannel.length > 5 ? 'user-list-grid' : 'user-list-stacked';

    return (
        <div className="w-full flex-shrink-0 h-full snap-center flex flex-col" data-channel-id={channel.id}>
            <div className="flex justify-center items-center mb-2 px-3 pt-3">
                <div className="inline-flex items-center px-4 py-1.5 font-semibold text-white rounded-full bg-green-600 border-b-4 border-green-900 shadow-sm" style={{justifyContent: 'center', minWidth: 0}}>
                    <span className="truncate">{channel.name}</span>
                    <div className="ml-3 inline-flex items-center px-2 py-0.5 bg-black bg-opacity-20 rounded-full text-xs flex-shrink-0">
                        <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd"></path></svg>
                        <span>{usersInChannel.length}</span>
                    </div>
                </div>
            </div>
            <div className={`speaker-box mx-3 mb-2 ${!talkingUser ? 'empty' : ''}`} style={!talkingUser ? { justifyContent: 'center' } : {}}>
                {talkingUser ? (
                    <UserBox user={talkingUser} />
                ) : isLoadingSuggestion ? (
                    <SuggestionText isLoading>Memuat saran topik...</SuggestionText>
                ) : suggestion ? (
                    <SuggestionText>
                        <span role="img" aria-label="light-bulb">💡</span> <span className="opacity-80">Saran Topik:</span> {suggestion}
                    </SuggestionText>
                ) : (
                    <div className="running-text-container w-full">Channel Sepi...</div>
                )}
            </div>
            <div className="flex-grow custom-scrollbar overflow-y-auto px-3 pb-4">
                <div className={userListClass}>
                    {otherUsers.length > 0 ? (
                        otherUsers.map(user => <UserBox key={user.uid} user={user} />)
                    ) : (
                        <p className="text-sm text-center italic mt-4 text-gray-500 dark:text-gray-400">Channel ini sepi...</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Room;
