
import React, { useRef, useEffect, useCallback } from 'react';
import { useAppContext } from '../../context/AppContext';
import Room from './Room';

const RoomSwiper: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { channels, currentChannelIndex } = state;
    const swiperRef = useRef<HTMLDivElement>(null);
    const scrollTimeoutRef = useRef<number | null>(null);

    const handleScroll = useCallback(() => {
        if (scrollTimeoutRef.current) {
            clearTimeout(scrollTimeoutRef.current);
        }
        scrollTimeoutRef.current = window.setTimeout(() => {
            if (swiperRef.current) {
                const { scrollLeft, offsetWidth } = swiperRef.current;
                const newIndex = Math.round(scrollLeft / offsetWidth);
                if (newIndex !== currentChannelIndex) {
                    dispatch({ type: 'SET_CURRENT_CHANNEL_INDEX', payload: newIndex });
                }
            }
        }, 150);
    }, [currentChannelIndex, dispatch]);

    useEffect(() => {
        const swiper = swiperRef.current;
        if (swiper) {
            swiper.addEventListener('scroll', handleScroll);
            return () => {
                swiper.removeEventListener('scroll', handleScroll);
                if (scrollTimeoutRef.current) {
                    clearTimeout(scrollTimeoutRef.current);
                }
            };
        }
    }, [handleScroll]);

    useEffect(() => {
        if (swiperRef.current) {
            const targetScrollLeft = currentChannelIndex * swiperRef.current.offsetWidth;
            if (swiperRef.current.scrollLeft !== targetScrollLeft) {
                swiperRef.current.scrollTo({
                    left: targetScrollLeft,
                    behavior: 'smooth'
                });
            }
        }
    }, [currentChannelIndex]);


    return (
        <>
            <main ref={swiperRef} className="absolute inset-0 flex overflow-x-auto snap-x snap-mandatory no-scrollbar">
                {channels.length > 0 ? (
                    channels.map(channel => <Room key={channel.id} channel={channel} />)
                ) : (
                    <div className="w-full h-full flex items-center justify-center text-center p-4">
                        <div className="flex flex-col items-center">
                             <svg className="w-16 h-16 text-gray-300 dark:text-gray-600 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a2 2 0 01-2-2V10a2 2 0 012-2h8z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16H5a2 2 0 01-2-2V8a2 2 0 012-2h2"></path></svg>
                            <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-300">Tidak Ada Room</h3>
                            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Buat room baru dari menu pengaturan.</p>
                        </div>
                    </div>
                )}
            </main>
            <div className="absolute bottom-2 left-0 right-0 flex justify-center items-center space-x-2">
                {channels.map((_, index) => (
                    <button
                        key={index}
                        onClick={() => dispatch({ type: 'SET_CURRENT_CHANNEL_INDEX', payload: index })}
                        className={`w-2 h-2 rounded-full transition-colors ${index === currentChannelIndex ? 'bg-green-600' : 'bg-gray-300 dark:bg-gray-600'}`}
                    ></button>
                ))}
            </div>
        </>
    );
};

export default RoomSwiper;
