
import React, { useMemo } from 'react';
import { useAppContext } from '../../context/AppContext';

const SawerButton: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { presences, users, currentChannelIndex, channels } = state;

    const currentChannelId = channels[currentChannelIndex]?.id;

    const talkingUserInCurrentChannel = useMemo(() => {
        if (!currentChannelId) return null;
        const talkingPresence = Object.values(presences).find(p => p.channelId === currentChannelId && p.isTalking);
        return talkingPresence ? users[talkingPresence.uid] : null;
    }, [presences, users, currentChannelId]);

    const handleSawerClick = () => {
        if (talkingUserInCurrentChannel) {
            dispatch({ type: 'SHOW_MODAL', payload: { type: 'sawer', data: talkingUserInCurrentChannel } });
        }
    };

    const isEnabled = talkingUserInCurrentChannel !== null;

    return (
        <button
            id="mainSawerBtn"
            title={isEnabled ? `Sawer ${talkingUserInCurrentChannel?.profile.name}` : "Tidak ada yang berbicara"}
            onClick={handleSawerClick}
            disabled={!isEnabled}
            className="fixed right-4 w-14 h-14 md:w-16 md:h-16 rounded-full flex items-center justify-center z-40"
            style={{ bottom: 'calc(var(--ptt-h) + 1.5rem + env(safe-area-inset-bottom))' }}
        >
            <svg className="w-8 h-8" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                <defs>
                    <radialGradient id="coinGradientBtn" cx="50%" cy="50%" r="50%" fx="25%" fy="25%">
                        <stop offset="0%" stopColor="#FDE047" />
                        <stop offset="100%" stopColor="#F59E0B" />
                    </radialGradient>
                </defs>
                <circle cx="10" cy="10" r="9" fill="url(#coinGradientBtn)" />
                <circle cx="10" cy="10" r="9" fill="transparent" stroke="#B45309" strokeWidth="1.2" />
                <path d="M10 5.5C10.5523 5.5 11 5.94772 11 6.5V13.5C11 14.0523 10.5523 14.5 10 14.5C9.44772 14.5 9 14.0523 9 13.5V6.5C9 5.94772 9.44772 5.5 10 5.5Z" fill="#FBBF24" fillOpacity="0.8" />
                <path d="M12.5 7.5C13.0523 7.5 13.5 7.94772 13.5 8.5V11.5C13.5 12.0523 13.0523 12.5 12.5 12.5C11.9477 12.5 11.5 12.0523 11.5 11.5V8.5C11.5 7.94772 11.9477 7.5 12.5 7.5Z" fill="#FBBF24" fillOpacity="0.8" />
                <path d="M7.5 7.5C8.05228 7.5 8.5 7.94772 8.5 8.5V11.5C8.5 12.0523 8.05228 12.5 7.5 12.5C6.94772 12.5 6.5 12.0523 6.5 11.5V8.5C6.5 7.94772 6.94772 7.5 7.5 7.5Z" fill="#FBBF24" fillOpacity="0.8" />
            </svg>
        </button>
    );
};

export default SawerButton;
