import React, { useMemo } from 'react';
import type { User, Presence } from '../../types';
import { useAppContext } from '../../context/AppContext';
import { ICONS } from '../../constants';

interface UserBoxProps {
    user: {
        uid: string;
        profile: User['profile'];
        presence: Presence;
    };
}

const UserBox: React.FC<UserBoxProps> = ({ user }) => {
    const { dispatch, state: { isAdmin, currentUser } } = useAppContext();

    const canModerate = useMemo(() => {
        if (!currentUser || !user) return false;
        if (currentUser.uid === user.uid) return false; // Can't moderate self
        if (isAdmin) return true;
        if (currentUser.profile.moderatorRole === 'global') return true;
        if (currentUser.profile.moderatorRole === 'room' && currentUser.profile.managedChannelId === user.presence.channelId) {
            return true;
        }
        return false;
    }, [currentUser, user, isAdmin]);

    const avatarUrl = (user.profile.photos && user.profile.photos.length > 0)
        ? user.profile.photos[user.profile.avatarIndex || 0]
        : `https://placehold.co/96x96/16a34a/ffffff?text=${user.profile.name.charAt(0)}`;
    
    const handleBoxClick = () => {
        if (canModerate) {
            dispatch({ type: 'SHOW_MODAL', payload: { type: 'admin-user-actions', data: user } });
        } else {
            dispatch({ type: 'SHOW_MODAL', payload: { type: 'user-profile', data: user } });
        }
    };

    return (
        <div 
            id={`user-box-${user.uid}`}
            onClick={handleBoxClick}
            className={`user-box rounded-xl p-2 flex items-center gap-3 cursor-pointer ${user.presence.isTalking ? 'is-talking' : ''} ${user.profile.isVip ? 'vip' : ''}`}
        >
            <div className="flex items-center gap-3 flex-grow overflow-hidden">
                <div className="relative flex-shrink-0">
                    <img src={avatarUrl} alt={`Avatar ${user.profile.name}`} className="w-12 h-12 object-cover rounded-md border-2 border-white shadow-sm" />
                    {(user.presence.isMicMuted || user.presence.isDeafened) && (
                         <div className="absolute inset-0 bg-black bg-opacity-60 rounded-md flex items-center justify-center gap-1 text-white">
                            {user.presence.isDeafened ? (
                                <div dangerouslySetInnerHTML={{ __html: ICONS.speakerOff }} className="w-5 h-5" title="Deafened"></div>
                            ) : user.presence.isMicMuted ? (
                                 <div dangerouslySetInnerHTML={{ __html: ICONS.micOff }} className="w-5 h-5" title="Mic Muted"></div>
                            ) : null}
                        </div>
                    )}
                </div>
                <div className="flex-grow overflow-hidden min-w-0">
                    <div className="flex items-center">
                        <p className="font-semibold text-white truncate">{user.profile.name}</p>
                        {user.profile.isVip && (
                            <span className="vip-badge" title="Pengguna VIP">
                                <svg className="w-4 h-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 2a.75.75 0 01.707.443l1.25 2.501a.75.75 0 001.192.41l2.357-1.178a.75.75 0 01.98.98l-1.178 2.357a.75.75 0 00.41 1.192l2.501 1.25A.75.75 0 0118 10v.001a.75.75 0 01-.443.707l-2.5 1.25a.75.75 0 00-.41 1.192l1.178 2.357a.75.75 0 01-.98.98l-2.357-1.178a.75.75 0 00-1.192.41l-1.25 2.501A.75.75 0 0110 18a.75.75 0 01-.707-.443l-1.25-2.501a.75.75 0 00-1.192-.41l-2.357 1.178a.75.75 0 01-.98-.98l1.178-2.357a.75.75 0 00-.41-1.192l-2.5-1.25A.75.75 0 012 10V9.999a.75.75 0 01.443-.707l2.5-1.25a.75.75 0 00.41-1.192L4.178 4.49a.75.75 0 01.98-.98l2.357 1.178a.75.75 0 001.192.41l1.25-2.501A.75.75 0 0110 2zM8.5 9.5a1.5 1.5 0 113 0 1.5 1.5 0 01-3 0z" clipRule="evenodd" /></svg>
                            </span>
                        )}
                        {user.profile.moderatorRole && user.profile.moderatorRole !== 'none' && (
                             <span 
                                className={`mod-badge ${user.profile.moderatorRole}`} 
                                title={user.profile.moderatorRole === 'global' ? 'Moderator Global' : 'Moderator Room'}
                            >
                                {user.profile.moderatorRole === 'global' ? (
                                    <svg className="w-4 h-4" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                        <path fill="currentColor" d="M10 2L3 4.5v5c0 4.14 3.14 7.5 7 7.5s7-3.36 7-7.5v-5L10 2z"/>
                                        <path fill="white" d="m10 6.09 1.45 2.94 3.25.47-2.35 2.29.55 3.24L10 13.2l-2.9 1.53.55-3.24-2.35-2.29 3.25-.47L10 6.09z"/>
                                    </svg>
                                ) : (
                                    <svg className="w-4 h-4" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                        <path fill="currentColor" d="M10 2L3 4.5v5c0 4.14 3.14 7.5 7 7.5s7-3.36 7-7.5v-5L10 2z"/>
                                        <path fill="white" d="M10 6.5l-3 3V13h2v-3h2v3h2v-3.5l-3-3z"/>
                                    </svg>
                                )}
                            </span>
                        )}
                    </div>
                    <p className="text-xs text-green-100 flex items-center gap-1.5 truncate">
                        <span>🇮🇩</span>
                        <span className="truncate">{user.profile.address}</span>
                    </p>
                </div>
            </div>
            <div className="flex flex-col items-end gap-2 flex-shrink-0">
                <div className="coin-display flex items-center justify-end gap-1 text-xs font-semibold">
                    <svg className="w-4 h-4" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><defs><radialGradient id={`coinGradientSmall-${user.uid}`} cx="50%" cy="50%" r="50%" fx="25%" fy="25%"><stop offset="0%" stopColor="#FDE047"/><stop offset="100%" stopColor="#F59E0B"/></radialGradient></defs><circle cx="10" cy="10" r="9" fill={`url(#coinGradientSmall-${user.uid})`}/><circle cx="10" cy="10" r="9" fill="transparent" stroke="#B45309" strokeWidth="1.2"/><path d="M10 5.5C10.5523 5.5 11 5.94772 11 6.5V13.5C11 14.0523 10.5523 14.5 10 14.5C9.44772 14.5 9 14.0523 9 13.5V6.5C9 5.94772 9.44772 5.5 10 5.5Z" fill="#FBBF24" fillOpacity="0.8"/><path d="M12.5 7.5C13.0523 7.5 13.5 7.94772 13.5 8.5V11.5C13.5 12.0523 13.0523 12.5 12.5 12.5C11.9477 12.5 11.5 12.0523 11.5 11.5V8.5C11.5 7.94772 11.9477 7.5 12.5 7.5Z" fill="#FBBF24" fillOpacity="0.8"/><path d="M7.5 7.5C8.05228 7.5 8.5 7.94772 8.5 8.5V11.5C8.5 12.0523 8.05228 12.5 7.5 12.5C6.94772 12.5 6.5 12.0523 6.5 11.5V8.5C6.5 7.94772 6.94772 7.5 7.5 7.5Z" fill="#FBBF24" fillOpacity="0.8"/></svg>
                    <span>{user.uid === 'admin-bos-sn' ? '∞' : (user.profile.coins ?? 0)}</span>
                </div>
            </div>
        </div>
    );
};

export default UserBox;