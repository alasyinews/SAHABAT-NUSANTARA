import React, { useState, useEffect } from 'react';
import { useAppContext } from '../../context/AppContext';
import type { Channel } from '../../types';
import Modal from '../ui/Modal';

const AdminEditChannelModal: React.FC = () => {
    const { state, dispatch, showToast } = useAppContext();
    const { modal } = state;

    const isOpen = modal.type === 'admin-edit-channel';
    const channelToEdit = modal.data as Channel | undefined;

    const [name, setName] = useState('');
    const [isLocked, setIsLocked] = useState(false);

    useEffect(() => {
        if (isOpen && channelToEdit) {
            setName(channelToEdit.name);
            setIsLocked(channelToEdit.isLocked || false);
        }
    }, [isOpen, channelToEdit]);
    
    const handleClose = () => dispatch({ type: 'HIDE_MODAL' });

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!channelToEdit || !name.trim()) return;
        dispatch({
            type: 'ADMIN_EDIT_CHANNEL',
            payload: { ...channelToEdit, name: name.trim(), isLocked }
        });
        showToast('Channel berhasil diperbarui.');
        handleClose();
    };

    if (!channelToEdit) return null;

    return (
        <Modal isOpen={isOpen} onClose={handleClose} contentClasses="p-6">
            <h3 className="text-xl font-bold mb-4">Edit Channel: {channelToEdit.name}</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="edit-channel-name" className="block text-sm font-medium">Nama Channel</label>
                    <input type="text" id="edit-channel-name" value={name} onChange={e => setName(e.target.value)} className="mt-1 w-full p-2 border rounded-md dark:bg-gray-700 dark:border-gray-600" />
                </div>
                <div>
                    <div className="flex items-center">
                        <input type="checkbox" id="edit-channel-locked" checked={isLocked} onChange={e => setIsLocked(e.target.checked)} className="h-4 w-4 text-green-600 border-gray-300 rounded focus:ring-green-500" />
                        <label htmlFor="edit-channel-locked" className="ml-2 block text-sm font-medium">Kunci Channel (Hanya Admin)</label>
                    </div>
                </div>
                <div className="mt-6 flex justify-end gap-3">
                    <button type="button" onClick={handleClose} className="px-4 py-2 bg-gray-200 rounded-md hover:bg-gray-300 dark:bg-gray-600 dark:hover:bg-gray-500">Batal</button>
                    <button type="submit" className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">Simpan</button>
                </div>
            </form>
        </Modal>
    );
};

export default AdminEditChannelModal;
