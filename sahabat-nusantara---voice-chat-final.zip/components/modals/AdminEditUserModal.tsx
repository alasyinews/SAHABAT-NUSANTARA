

import React, { useState, useEffect } from 'react';
import { useAppContext } from '../../context/AppContext';
import Modal from '../ui/Modal';
import type { User, Profile, ModeratorPermissions } from '../../types';

const PermissionCheckbox: React.FC<{
    id: string;
    label: string;
    checked: boolean;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}> = ({ id, label, checked, onChange }) => (
    <div className="flex items-center">
        <input 
            type="checkbox" 
            id={id} 
            checked={checked} 
            onChange={onChange} 
            className="h-4 w-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
        />
        <label htmlFor={id} className="ml-2 block text-sm font-medium">{label}</label>
    </div>
);

const AdminEditUserModal: React.FC = () => {
    const { state, dispatch, showToast } = useAppContext();
    const { modal, channels } = state;
    
    const isOpen = modal.type === 'admin-edit-user';
    const userToEdit = modal.data as User | undefined;

    const [coins, setCoins] = useState(0);
    const [isVip, setIsVip] = useState(false);
    const [moderatorRole, setModeratorRole] = useState<'none' | 'room' | 'global'>('none');
    const [managedChannelId, setManagedChannelId] = useState<string | null>(null);
    const [permissions, setPermissions] = useState<ModeratorPermissions>({
        canKick: false,
        canMove: false,
        canMuteDeafen: false,
        canChangeRoomMode: false,
        canBan: false,
    });

    useEffect(() => {
        if (isOpen && userToEdit?.profile) {
            const profile = userToEdit.profile;
            setCoins(profile.coins);
            setIsVip(profile.isVip);
            setModeratorRole(profile.moderatorRole || 'none');
            setManagedChannelId(profile.managedChannelId || (channels.length > 0 ? channels[0].id : null));
            setPermissions({
                canKick: profile.moderatorPermissions?.canKick ?? false,
                canMove: profile.moderatorPermissions?.canMove ?? false,
                canMuteDeafen: profile.moderatorPermissions?.canMuteDeafen ?? false,
                canChangeRoomMode: profile.moderatorPermissions?.canChangeRoomMode ?? false,
                canBan: profile.moderatorPermissions?.canBan ?? false,
            });
        }
    }, [isOpen, userToEdit, channels]);

    const handleClose = () => {
        dispatch({ type: 'HIDE_MODAL' });
        dispatch({ type: 'SHOW_MODAL', payload: { type: 'admin-panel' } });
    };

    const handlePermissionChange = (perm: keyof ModeratorPermissions) => {
        setPermissions(prev => ({ ...prev, [perm]: !prev[perm] }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!userToEdit?.profile) return;

        const data: Partial<Profile> = {
            isVip,
            moderatorRole,
            managedChannelId: moderatorRole === 'room' ? managedChannelId : null,
            moderatorPermissions: moderatorRole !== 'none' ? permissions : {},
        };
        
        if (userToEdit.uid !== 'admin-bos-sn') {
            data.coins = Number(coins);
        }

        dispatch({
            type: 'ADMIN_UPDATE_USER_PROFILE',
            payload: {
                uid: userToEdit.uid,
                data
            }
        });
        showToast(`Profil ${userToEdit.profile.name} diperbarui.`);
        handleClose();
    };

    if (!userToEdit?.profile) return null;

    return (
        <Modal isOpen={isOpen} onClose={handleClose} contentClasses="p-6 max-h-[90vh] flex flex-col">
            <h3 className="text-xl font-bold mb-4 flex-shrink-0">Edit Pengguna: {userToEdit.profile.name}</h3>
            <form onSubmit={handleSubmit} className="flex flex-col flex-grow min-h-0">
                <div className="space-y-4 flex-grow overflow-y-auto custom-scrollbar pr-2 -mr-2">
                    <div>
                        <label htmlFor="edit-coins" className="block text-sm font-medium">Koin</label>
                        {userToEdit.uid === 'admin-bos-sn' ? (
                            <div className="mt-1 w-full p-2 border rounded-md bg-gray-200 dark:bg-gray-800 dark:border-gray-600 text-center font-bold text-lg text-gray-500">
                                ∞
                            </div>
                        ) : (
                            <input 
                                type="number" 
                                id="edit-coins" 
                                value={coins} 
                                onChange={e => setCoins(parseInt(e.target.value, 10) || 0)} 
                                className="mt-1 w-full p-2 border rounded-md dark:bg-gray-700 dark:border-gray-600"
                            />
                        )}
                    </div>
                    <div>
                        <div className="flex items-center">
                             <input 
                                type="checkbox" 
                                id="edit-vip" 
                                checked={isVip} 
                                onChange={e => setIsVip(e.target.checked)} 
                                className="h-4 w-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
                            />
                            <label htmlFor="edit-vip" className="ml-2 block text-sm font-medium">Status VIP</label>
                        </div>
                    </div>
                    <div className="pt-2 border-t dark:border-gray-600">
                        <label htmlFor="edit-mod-role" className="block text-sm font-medium">Peran Moderator</label>
                         <select
                            id="edit-mod-role"
                            value={moderatorRole}
                            onChange={(e) => setModeratorRole(e.target.value as 'none' | 'room' | 'global')}
                            className="mt-1 block w-full p-2 border rounded-md dark:bg-gray-700 dark:border-gray-600"
                        >
                            <option value="none">Bukan Moderator</option>
                            <option value="room">Moderator Room</option>
                            <option value="global">Moderator Global</option>
                        </select>
                    </div>
                    {moderatorRole === 'room' && (
                        <div>
                            <label htmlFor="edit-managed-channel" className="block text-sm font-medium">Kelola Room</label>
                            <select
                                id="edit-managed-channel"
                                value={managedChannelId || ''}
                                onChange={(e) => setManagedChannelId(e.target.value)}
                                className="mt-1 block w-full p-2 border rounded-md dark:bg-gray-700 dark:border-gray-600"
                            >
                                {channels.map(channel => (
                                    <option key={channel.id} value={channel.id}>{channel.name}</option>
                                ))}
                            </select>
                        </div>
                    )}

                    {moderatorRole !== 'none' && (
                        <div className="pt-2 border-t dark:border-gray-600">
                            <p className="block text-sm font-medium mb-2">Izin Moderator</p>
                            <div className="grid grid-cols-2 gap-x-4 gap-y-2 p-2 bg-gray-50 dark:bg-gray-900/50 rounded-md">
                                <PermissionCheckbox id="perm-kick" label="Menendang Pengguna" checked={permissions.canKick || false} onChange={() => handlePermissionChange('canKick')} />
                                <PermissionCheckbox id="perm-move" label="Memindahkan Pengguna" checked={permissions.canMove || false} onChange={() => handlePermissionChange('canMove')} />
                                <PermissionCheckbox id="perm-mute" label="Membisukan/Tuli" checked={permissions.canMuteDeafen || false} onChange={() => handlePermissionChange('canMuteDeafen')} />
                                <PermissionCheckbox id="perm-mode" label="Ubah Mode Room" checked={permissions.canChangeRoomMode || false} onChange={() => handlePermissionChange('canChangeRoomMode')} />
                                <div className="col-span-2">
                                   <PermissionCheckbox id="perm-ban" label="Blokir Pengguna" checked={permissions.canBan || false} onChange={() => handlePermissionChange('canBan')} />
                                </div>
                            </div>
                        </div>
                    )}
                </div>
                <div className="mt-6 flex justify-end gap-3 flex-shrink-0 border-t dark:border-gray-600 pt-4">
                    <button type="button" onClick={handleClose} className="px-4 py-2 bg-gray-200 rounded-md hover:bg-gray-300 dark:bg-gray-600 dark:hover:bg-gray-500">Batal</button>
                    <button type="submit" className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">Simpan</button>
                </div>
            </form>
        </Modal>
    );
};

export default AdminEditUserModal;