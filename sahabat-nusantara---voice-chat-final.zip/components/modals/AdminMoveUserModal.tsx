import React from 'react';
import { useAppContext } from '../../context/AppContext';
import Modal from '../ui/Modal';
import type { User, Presence } from '../../types';

const AdminMoveUserModal: React.FC = () => {
    const { state, dispatch, showToast } = useAppContext();
    const { modal, channels } = state;

    const isOpen = modal.type === 'admin-move-user-room-select';
    const user = (modal.data as {uid: string, profile: User['profile'], presence: Presence}) || null;

    if (!isOpen || !user || !user.profile) return null;

    const handleClose = () => {
        dispatch({ type: 'HIDE_MODAL' });
    };

    const handleMove = (newChannelId: string, newChannelName: string) => {
        dispatch({
            type: 'SHOW_MODAL',
            payload: {
                type: 'confirmation',
                data: {
                    title: 'Pindahkan Pengguna',
                    message: `Pindahkan ${user.profile.name} ke room "${newChannelName}"?`,
                    confirmText: 'Ya, Pindahkan',
                    onConfirm: () => {
                        dispatch({ type: 'ADMIN_MOVE_USER', payload: { uid: user.uid, newChannelId: newChannelId } });
                        showToast(`${user.profile.name} telah dipindahkan.`);
                    }
                }
            }
        });
    };

    const userCurrentChannelId = user.presence.channelId;
    const availableChannels = channels.filter(c => c.id !== userCurrentChannelId && !c.isLocked);

    return (
        <Modal isOpen={isOpen} onClose={handleClose} contentClasses="p-6">
            <h3 className="text-xl font-bold mb-1">Pindahkan Pengguna</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-4">Pilih room tujuan untuk <span className="font-semibold">{user.profile.name}</span>.</p>
            <div className="space-y-2 max-h-60 overflow-y-auto custom-scrollbar pr-2 -mr-2">
                {availableChannels.length > 0 ? (
                    availableChannels.map(channel => (
                        <button
                            key={channel.id}
                            onClick={() => handleMove(channel.id, channel.name)}
                            className="w-full text-left p-3 rounded-lg bg-gray-100 text-gray-800 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600 flex items-center gap-3 transition-colors"
                        >
                             <svg className="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 9l3 3m0 0l-3 3m3-3H8m13 0a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                            <span className="truncate">{channel.name}</span>
                        </button>
                    ))
                ) : (
                    <p className="text-sm text-center italic text-gray-500 dark:text-gray-400 py-4">
                        Tidak ada room lain yang tersedia untuk dipindahkan.
                    </p>
                )}
            </div>
            <div className="mt-6 flex justify-end">
                <button
                    type="button"
                    onClick={handleClose}
                    className="btn-3d btn-gray-3d text-sm"
                >
                    Batal
                </button>
            </div>
        </Modal>
    );
};

export default AdminMoveUserModal;
