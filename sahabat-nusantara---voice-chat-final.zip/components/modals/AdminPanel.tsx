import React, { useState, useMemo } from 'react';
import { useAppContext } from '../../context/AppContext';
import type { User } from '../../types';

const AdminPanel: React.FC = () => {
    const { state, dispatch, showToast, setAppStatus, state: { currentUser } } = useAppContext();
    const { modal, users } = state;
    const [searchTerm, setSearchTerm] = useState('');

    const isOpen = modal.type === 'admin-panel';

    const handleClose = () => {
        dispatch({ type: 'HIDE_MODAL' });
        setSearchTerm('');
    };

    const handleEditUser = (user: User) => {
        dispatch({ type: 'SHOW_MODAL', payload: { type: 'admin-edit-user', data: user } });
    };

    const handleToggleBan = (user: User) => {
        const isBanned = !user.profile.isBanned;
        dispatch({
            type: 'ADMIN_UPDATE_USER_PROFILE',
            payload: { uid: user.uid, data: { isBanned } }
        });
        showToast(`${user.profile.name} telah ${isBanned ? 'diblokir' : 'dibuka blokirnya'}.`);
    };
    
    const handleDeleteUser = (user: User) => {
        dispatch({
            type: 'SHOW_MODAL',
            payload: {
                type: 'confirmation',
                data: {
                    title: 'Hapus Pengguna',
                    message: `Apakah Anda yakin ingin menghapus ${user.profile.name}? Tindakan ini tidak dapat diurungkan.`,
                    confirmText: 'Ya, Hapus',
                    confirmColor: 'red',
                    onConfirm: () => {
                        dispatch({ type: 'ADMIN_DELETE_USER', payload: { uid: user.uid } });
                        showToast(`Pengguna ${user.profile.name} telah dihapus.`);
                        if(currentUser?.uid === user.uid) {
                             setTimeout(() => setAppStatus('login'), 100);
                        }
                    }
                }
            }
        });
    };
    
    const filteredUsers = useMemo(() => 
        Object.values(users).filter(user => 
            user && user.profile && user.profile.name.toLowerCase().includes(searchTerm.toLowerCase())
        ),
        [users, searchTerm]
    );

    if (!isOpen) return null;

    return (
        <div 
            className={`fixed inset-0 bg-white dark:bg-gray-900 z-[90] flex flex-col transition-transform duration-300 ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}
        >
            <div className="p-4 border-b dark:border-gray-700 flex justify-between items-center flex-shrink-0">
                <h3 className="text-lg font-bold">Panel Admin - Manajemen Pengguna</h3>
                <button onClick={handleClose} className="text-gray-500 hover:text-gray-800 dark:hover:text-gray-200" aria-label="Tutup Panel Admin">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
            </div>
             <div className="p-4 border-b dark:border-gray-700 flex-shrink-0">
                <div className="relative">
                     <input 
                        type="text" 
                        placeholder="Cari pengguna..."
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                        className="w-full p-2 pl-10 border rounded-md bg-gray-50 dark:bg-gray-800 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-green-500"
                        aria-label="Cari pengguna"
                    />
                    <svg className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                </div>
            </div>
            <div className="flex-grow p-4 overflow-y-auto custom-scrollbar">
                <div className="space-y-1">
                    {filteredUsers.length > 0 ? (
                        filteredUsers.map(user => {
                            const avatarUrl = (user.profile.photos && user.profile.photos.length > 0)
                                ? user.profile.photos[user.profile.avatarIndex || 0]
                                : `https://placehold.co/40x40/16a34a/ffffff?text=${user.profile.name.charAt(0)}`;
                            return (
                                <div key={user.uid} className={`p-2 rounded-lg flex items-center gap-3 ${user.profile.isBanned ? 'bg-red-100 dark:bg-red-900/50' : 'bg-gray-50 dark:bg-gray-800'}`}>
                                    <img src={avatarUrl} alt={user.profile.name} className="w-10 h-10 rounded-full object-cover"/>
                                    <div className="flex-grow">
                                        <p className="font-semibold">{user.profile.name} {user.profile.isVip && '⭐'}</p>
                                        <p className="text-sm text-gray-500 dark:text-gray-400">Koin: {user.uid === 'admin-bos-sn' ? '∞' : (user.profile.coins ?? 0)}</p>
                                    </div>
                                    <div className="flex gap-2">
                                        <button onClick={() => handleEditUser(user)} className="px-3 py-1 text-sm bg-blue-500 text-white rounded-md hover:bg-blue-600">Edit</button>
                                        <button onClick={() => handleToggleBan(user)} className={`px-3 py-1 text-sm text-white rounded-md ${user.profile.isBanned ? 'bg-green-500 hover:bg-green-600' : 'bg-red-500 hover:bg-red-600'}`}>
                                            {user.profile.isBanned ? 'Buka' : 'Blokir'}
                                        </button>
                                         <button onClick={() => handleDeleteUser(user)} className="px-3 py-1 text-sm bg-gray-500 text-white rounded-md hover:bg-gray-600">Hapus</button>
                                    </div>
                                </div>
                            );
                        })
                    ) : (
                         <p className="text-center text-gray-500 dark:text-gray-400 mt-8">Pengguna tidak ditemukan.</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default AdminPanel;