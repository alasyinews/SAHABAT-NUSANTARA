import React from 'react';
import { useAppContext } from '../../context/AppContext';
import Modal from '../ui/Modal';
import type { User, Presence } from '../../types';

const AdminUserActionsModal: React.FC = () => {
    const { state, dispatch, showToast } = useAppContext();
    const { modal, channels, currentUser, isAdmin } = state;

    const isOpen = modal.type === 'admin-user-actions';
    const user = (modal.data as {uid: string, profile: User['profile'], presence: Presence}) || null;

    if (!isOpen || !user || !user.profile || !currentUser) return null;

    const isGlobalMod = currentUser.profile.moderatorRole === 'global';
    const isRoomModForThisRoom = currentUser.profile.moderatorRole === 'room' && currentUser.profile.managedChannelId === user.presence.channelId;
    const canModerate = isGlobalMod || isRoomModForThisRoom;
    const modPerms = currentUser.profile.moderatorPermissions || {};

    const handleClose = () => {
        dispatch({ type: 'HIDE_MODAL' });
    };

    const handleKick = () => {
        const defaultChannelId = channels[0]?.id;
        if (defaultChannelId) {
            dispatch({ type: 'ADMIN_MOVE_USER', payload: { uid: user.uid, newChannelId: defaultChannelId } });
            showToast(`${user.profile.name} telah di-kick.`);
        }
        handleClose();
    };
    
    const handleToggleMute = () => {
        const isMuted = !user.presence.isMicMuted;
        dispatch({ type: 'UPDATE_USER_PRESENCE', payload: { uid: user.uid, isMicMuted: isMuted } });
        showToast(`${user.profile.name} telah di-${isMuted ? 'mute' : 'unmute'}.`);
        handleClose();
    };

    const handleToggleDeafen = () => {
        const isDeafened = !user.presence.isDeafened;
        const presenceUpdate = isDeafened
            ? { isDeafened: true, isMicMuted: true }
            : { isDeafened: false };
        dispatch({ type: 'UPDATE_USER_PRESENCE', payload: { uid: user.uid, ...presenceUpdate } });
        showToast(`${user.profile.name} telah di-${isDeafened ? 'deafen' : 'undeafen'}.`);
        handleClose();
    };


    const handleToggleBan = () => {
        const isBanned = !user.profile.isBanned;
        dispatch({ type: 'ADMIN_UPDATE_USER_PROFILE', payload: { uid: user.uid, data: { isBanned } } });
        showToast(`${user.profile.name} telah ${isBanned ? 'diblokir' : 'dibuka blokirnya'}.`);
        handleClose();
    };
    
    const handleOpenMoveModal = () => {
        dispatch({ type: 'SHOW_MODAL', payload: { type: 'admin-move-user-room-select', data: user } });
    };

    const avatarUrl = (user.profile.photos && user.profile.photos.length > 0)
        ? user.profile.photos[user.profile.avatarIndex || 0]
        : `https://placehold.co/48x48/16a34a/ffffff?text=${user.profile.name.charAt(0)}`;
        
    return (
        <Modal isOpen={isOpen} onClose={handleClose} contentClasses="p-0 max-h-[90vh] flex flex-col">
             <div className="p-4 border-b dark:border-gray-700 flex items-center gap-3 flex-shrink-0">
                <img src={avatarUrl} alt={user.profile.name} className="w-12 h-12 rounded-full object-cover"/>
                <div>
                    <h3 className="text-lg font-bold truncate">{user.profile.name}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Panel Aksi {isAdmin ? 'Admin' : 'Moderator'}</p>
                </div>
            </div>
            <div className="flex-grow p-4 overflow-y-auto custom-scrollbar">
                <div className="grid grid-cols-2 gap-4">
                     {(isAdmin || (canModerate && modPerms.canKick)) && (
                        <button onClick={handleKick} className="w-full btn-3d btn-yellow-3d text-base font-semibold flex flex-col items-center justify-center gap-2 py-4 rounded-xl">
                            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7l5 5m0 0l-5 5m5-5H6"></path></svg>
                            <span>Kick</span>
                        </button>
                     )}
                     {(isAdmin || (canModerate && modPerms.canMove)) && (
                         <button onClick={handleOpenMoveModal} className="w-full btn-3d btn-blue-3d text-base font-semibold flex flex-col items-center justify-center gap-2 py-4 rounded-xl">
                            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"></path></svg>
                            <span>Pindahkan</span>
                        </button>
                     )}
                     {(isAdmin || (canModerate && modPerms.canMuteDeafen)) && (
                         <>
                            <button onClick={handleToggleMute} className={`w-full btn-3d text-base font-semibold flex flex-col items-center justify-center gap-2 py-4 rounded-xl ${user.presence.isMicMuted ? 'btn-green-3d' : 'btn-red-3d'}`}>
                                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"></path></svg>
                                <span>{user.presence.isMicMuted ? 'Unmute' : 'Mute'}</span>
                            </button>
                             <button onClick={handleToggleDeafen} className={`w-full btn-3d text-base font-semibold flex flex-col items-center justify-center gap-2 py-4 rounded-xl ${user.presence.isDeafened ? 'btn-green-3d' : 'btn-red-3d'}`}>
                                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"></path></svg>
                                <span>{user.presence.isDeafened ? 'Undeafen' : 'Deafen'}</span>
                            </button>
                         </>
                     )}
                     {(isAdmin || (canModerate && modPerms.canBan)) && (
                         <button onClick={handleToggleBan} className={`col-span-2 w-full btn-3d text-base font-semibold flex flex-col items-center justify-center gap-2 py-4 rounded-xl ${user.profile.isBanned ? 'btn-green-3d' : 'btn-red-3d'}`}>
                            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"></path></svg>
                            <span>{user.profile.isBanned ? 'Buka Blokir' : 'Blokir'}</span>
                         </button>
                     )}
                </div>
            </div>
             <div className="p-3 bg-gray-50 dark:bg-gray-700/50 border-t dark:border-gray-700 flex-shrink-0">
                <button onClick={handleClose} className="w-full btn-3d btn-gray-3d text-sm">Tutup</button>
            </div>
        </Modal>
    );
};

export default AdminUserActionsModal;