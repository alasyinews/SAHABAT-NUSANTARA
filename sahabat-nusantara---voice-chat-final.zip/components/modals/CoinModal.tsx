
import React, { useState } from 'react';
import { useAppContext } from '../../context/AppContext';
import Modal from '../ui/Modal';

const CoinModal: React.FC = () => {
    const { state, dispatch, showToast } = useAppContext();
    const { modal, currentUser } = state;
    const [isLoading, setIsLoading] = useState(false);

    const isOpen = modal.type === 'coin';

    const handleClose = () => {
        dispatch({ type: 'HIDE_MODAL' });
    };

    const handleWatchAd = () => {
        setIsLoading(true);
        setTimeout(() => {
            const pointsEarned = 10;
            dispatch({
                type: 'UPDATE_CURRENT_USER_PROFILE',
                payload: { coins: (currentUser?.profile.coins || 0) + pointsEarned }
            });
            showToast(`Anda mendapatkan ${pointsEarned} poin!`);
            setIsLoading(false);
        }, 1500);
    };

    return (
        <Modal isOpen={isOpen} onClose={handleClose} contentClasses="p-6 text-center">
            <h3 className="text-2xl font-bold text-yellow-500 mb-2">Ruang Koin</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-4">Tonton iklan untuk mendapatkan poin dan mendukung komunitas!</p>
            <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg mb-6">
                <p className="text-lg font-bold">Poin Anda Saat Ini:</p>
                <p className="text-4xl font-bold text-green-600 dark:text-green-400">{currentUser?.profile.coins || 0}</p>
            </div>
            <button
                onClick={handleWatchAd}
                disabled={isLoading}
                className="w-full bg-blue-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-4 focus:ring-blue-300 transition-all duration-300 flex items-center justify-center gap-2 disabled:opacity-50"
            >
                <span className={isLoading ? 'hidden' : ''}>Tonton Iklan (+10 Poin)</span>
                {isLoading && <div className="loader" style={{ width: '20px', height: '20px', borderWidth: '2px', borderTopColor: 'white' }}></div>}
            </button>
            <button onClick={handleClose} className="mt-4 text-sm text-gray-500 hover:text-gray-700">Tutup</button>
        </Modal>
    );
};

export default CoinModal;
