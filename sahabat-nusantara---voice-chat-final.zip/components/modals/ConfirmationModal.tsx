import React from 'react';
import { useAppContext } from '../../context/AppContext';
import Modal from '../ui/Modal';

const ConfirmationModal: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { modal } = state;
    const { title, message, onConfirm, confirmText, confirmColor } = modal.data || {};

    const isOpen = modal.type === 'confirmation';
    if (!isOpen) return null;

    const handleClose = () => dispatch({ type: 'HIDE_MODAL' });
    
    const handleConfirm = () => {
        if (onConfirm) onConfirm();
        handleClose();
    };

    return (
        <Modal isOpen={isOpen} onClose={handleClose} contentClasses="p-6">
            <h3 className="text-xl font-bold mb-4">{title || 'Konfirmasi'}</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6">{message || 'Apakah Anda yakin?'}</p>
            <div className="flex justify-end gap-3">
                <button onClick={handleClose} className="btn-3d btn-gray-3d text-sm">Batal</button>
                <button onClick={handleConfirm} className={`btn-3d text-sm ${confirmColor === 'red' ? 'btn-red-3d' : 'btn-green-3d'}`}>
                    {confirmText || 'Ya, Lanjutkan'}
                </button>
            </div>
        </Modal>
    );
};

export default ConfirmationModal;