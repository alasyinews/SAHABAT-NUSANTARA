
import React, { useState, useEffect } from 'react';
import { useAppContext } from '../../context/AppContext';
import Modal from '../ui/Modal';
import type { Channel } from '../../types';

const CreateRoomModal: React.FC = () => {
    const { state, dispatch, showToast } = useAppContext();
    const { modal, currentUser, channels } = state;
    const [roomName, setRoomName] = useState('');
    const [error, setError] = useState('');

    const isOpen = modal.type === 'create-room';

    useEffect(() => {
        if (!isOpen) {
            setRoomName('');
            setError('');
        }
    }, [isOpen]);

    const handleClose = () => {
        dispatch({ type: 'HIDE_MODAL' });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!currentUser || roomName.trim() === '') {
            setError("Nama room tidak boleh kosong.");
            return;
        }

        const trimmedName = roomName.trim();
        if (channels.some(channel => channel.name.toLowerCase() === trimmedName.toLowerCase())) {
            setError("Room dengan nama serupa sudah ada.");
            return;
        }

        const newRoomId = `custom-${trimmedName.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')}-${Date.now()}`;

        const newChannel: Channel = {
            id: newRoomId,
            name: trimmedName,
            mode: 'talk',
            isTemporary: true,
            creatorId: currentUser.uid,
        };

        const newChannelIndex = channels.length;
        dispatch({ type: 'ADD_CHANNEL', payload: newChannel });
        showToast(`Room "${trimmedName}" berhasil dibuat!`);
        
        handleClose();
        
        setTimeout(() => {
            dispatch({ type: 'SET_CURRENT_CHANNEL_INDEX', payload: newChannelIndex });
        }, 100);
    };

    return (
        <Modal isOpen={isOpen} onClose={handleClose} contentClasses="p-6">
            <h3 className="text-xl font-bold mb-4 text-center">Buat Room Temporer</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 text-center mb-6">Room akan otomatis dihapus saat Anda keluar.</p>
            <form onSubmit={handleSubmit}>
                <div className="space-y-2">
                    <label htmlFor="room-name" className="block text-sm font-medium">Nama Room</label>
                    <input
                        type="text"
                        id="room-name"
                        value={roomName}
                        onChange={(e) => {
                            setRoomName(e.target.value);
                            if (error) setError('');
                        }}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:border-gray-600"
                        placeholder="Contoh: Diskusi Malam"
                        autoFocus
                    />
                    {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
                </div>
                <div className="mt-6 flex justify-end gap-3">
                    <button
                        type="button"
                        onClick={handleClose}
                        className="px-4 py-2 bg-gray-200 rounded-md hover:bg-gray-300 dark:bg-gray-600 dark:hover:bg-gray-500 font-semibold"
                    >
                        Batal
                    </button>
                    <button
                        type="submit"
                        disabled={!roomName.trim()}
                        className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        Buat Room
                    </button>
                </div>
            </form>
        </Modal>
    );
};

export default CreateRoomModal;