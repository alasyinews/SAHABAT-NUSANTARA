import React, { useState, useEffect } from 'react';
import { useAppContext } from '../../context/AppContext';
import Modal from '../ui/Modal';
import ProfileFormFields from '../ui/ProfileFormFields';

const EditProfileModal: React.FC = () => {
    const { state, dispatch, showToast } = useAppContext();
    const { modal, currentUser } = state;
    
    // States for editable fields
    const [name, setName] = useState('');
    const [bio, setBio] = useState('');
    const [photos, setPhotos] = useState<string[]>([]);
    const [avatarIndex, setAvatarIndex] = useState(0);

    const isOpen = modal.type === 'edit-profile';

    useEffect(() => {
        if (isOpen && currentUser) {
            setName(currentUser.profile.name);
            setBio(currentUser.profile.bio);
            setPhotos(currentUser.profile.photos || []);
            setAvatarIndex(currentUser.profile.avatarIndex || 0);
        }
    }, [isOpen, currentUser]);

    const handleClose = () => {
        dispatch({ type: 'HIDE_MODAL' });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!currentUser) return;

        const finalAvatarIndex = photos.length > 0 ? avatarIndex : 0;
        
        const payload = {
            name: name.trim(),
            bio: bio.trim(),
            photos: photos,
            avatarIndex: finalAvatarIndex,
        };

        dispatch({ type: 'UPDATE_CURRENT_USER_PROFILE', payload });
        
        const updatedProfile = { ...currentUser.profile, ...payload };
        localStorage.setItem(`sn_user_${currentUser.uid}`, JSON.stringify(updatedProfile));
        
        showToast('Profil berhasil diperbarui.');
        handleClose();
    };

    if (!currentUser) return null;

    return (
        <Modal isOpen={isOpen} onClose={handleClose} contentClasses="p-5 max-h-[90vh] flex flex-col">
            <h3 className="text-xl font-bold mb-4 flex-shrink-0">Edit Profil</h3>
            <form onSubmit={handleSubmit} className="space-y-4 overflow-y-auto custom-scrollbar pr-2 -mr-2 flex-grow">
                <div>
                    <label htmlFor="edit-name" className="block text-sm font-medium">Nama</label>
                    <input type="text" id="edit-name" value={name} onChange={e => setName(e.target.value)} className="mt-1 w-full p-2 border rounded-md dark:bg-gray-700 dark:border-gray-600" />
                </div>
                 <ProfileFormFields
                    photos={photos}
                    setPhotos={setPhotos}
                    bio={bio}
                    setBio={setBio}
                    currentUser={currentUser}
                    showToast={showToast}
                    avatarIndex={avatarIndex}
                    setAvatarIndex={setAvatarIndex}
                />
            </form>
            <div className="mt-4 pt-4 border-t dark:border-gray-600 flex justify-end gap-2 flex-shrink-0">
                <button type="button" onClick={handleClose} className="px-4 py-2 bg-gray-200 rounded-md hover:bg-gray-300 dark:bg-gray-600 dark:hover:bg-gray-500">Batal</button>
                <button type="button" onClick={handleSubmit} className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">Simpan</button>
            </div>
        </Modal>
    );
};

export default EditProfileModal;
