import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useAppContext } from '../../context/AppContext';
import type { PrivateMessage, User } from '../../types';

// Helper to generate a consistent conversation ID
const generateConversationId = (uid1: string, uid2: string): string => {
    return [uid1, uid2].sort().join('-');
};


const ChatView: React.FC<{ partner: User; onBack: () => void }> = ({ partner, onBack }) => {
    const { state, dispatch } = useAppContext();
    const { currentUser, privateMessages } = state;
    const [newMessage, setNewMessage] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);

    if (!currentUser || !partner.profile) return null;

    const conversationId = generateConversationId(currentUser.uid, partner.uid);
    const messages = privateMessages[conversationId] || [];

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (newMessage.trim() === '') return;

        const message: PrivateMessage = {
            id: `pm-${Date.now()}`,
            senderId: currentUser.uid,
            receiverId: partner.uid,
            text: newMessage.trim(),
            timestamp: new Date().toISOString(),
        };

        dispatch({
            type: 'ADD_PRIVATE_MESSAGE',
            payload: { conversationId, message }
        });

        setNewMessage('');
    };
    
    const partnerAvatar = (partner.profile.photos?.[0]) || `https://placehold.co/40x40/16a34a/ffffff?text=${partner.profile.name.charAt(0)}`;
    const currentUserAvatar = (currentUser.profile.photos?.[0]) || `https://placehold.co/40x40/16a34a/ffffff?text=${currentUser.profile.name.charAt(0)}`;

    return (
        <div className="h-full flex flex-col">
            <div className="p-4 border-b dark:border-gray-700 flex items-center gap-3">
                <button onClick={onBack} className="text-gray-500 hover:text-gray-800 dark:hover:text-gray-200" aria-label="Kembali">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
                </button>
                <img className="w-8 h-8 rounded-full" src={partnerAvatar} alt={partner.profile.name} />
                <h3 className="text-lg font-bold truncate">{partner.profile.name}</h3>
            </div>
            <div className="flex-grow p-4 overflow-y-auto custom-scrollbar">
                {messages.length === 0 ? (
                    <p className="text-center text-gray-500 p-4">Mulai percakapan!</p>
                ) : (
                    messages.map(msg => {
                        const isSelf = msg.senderId === currentUser.uid;
                        return (
                            <div key={msg.id} className={`flex items-start gap-2.5 mb-4 ${isSelf ? 'justify-end' : ''}`}>
                                {!isSelf && <img className="w-8 h-8 rounded-full" src={partnerAvatar} alt={`${partner.profile.name} avatar`} />}
                                <div className={`flex flex-col gap-1 max-w-[80%] ${isSelf ? 'items-end' : ''}`}>
                                    <div className={`leading-1.5 p-2 border-gray-200 ${isSelf ? 'bg-green-100 dark:bg-green-900 rounded-s-xl rounded-ee-xl' : 'bg-gray-100 dark:bg-gray-700 rounded-e-xl rounded-es-xl'}`}>
                                        <p className="text-sm font-normal text-gray-900 dark:text-white" style={{overflowWrap: 'break-word', wordBreak: 'break-word'}}>{msg.text}</p>
                                    </div>
                                </div>
                                {isSelf && <img className="w-8 h-8 rounded-full" src={currentUserAvatar} alt="My avatar" />}
                            </div>
                        );
                    })
                )}
                <div ref={messagesEndRef} />
            </div>
            <form onSubmit={handleSubmit} className="p-4 border-t dark:border-gray-700 flex gap-2">
                <input type="text" value={newMessage} onChange={e => setNewMessage(e.target.value)} className="flex-grow p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:border-gray-600" placeholder="Ketik pesan..." autoComplete="off" />
                <button type="submit" className="bg-green-600 text-white p-3 rounded-lg hover:bg-green-700 flex items-center justify-center" aria-label="Kirim Pesan">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path></svg>
                </button>
            </form>
        </div>
    );
};


const ConversationListView: React.FC<{ conversations: any[]; onSelect: (partnerId: string) => void }> = ({ conversations, onSelect }) => {
    return (
        <div className="flex-grow overflow-y-auto custom-scrollbar">
            {conversations.length === 0 ? (
                <div className="h-full flex items-center justify-center">
                    <p className="text-gray-500 text-center">Belum ada pesan pribadi.<br/>Mulai obrolan dari profil pengguna lain.</p>
                </div>
            ) : (
                conversations.map(({ partner, lastMessage }) => {
                     const avatar = (partner.profile.photos?.[0]) || `https://placehold.co/48x48/16a34a/ffffff?text=${partner.profile.name.charAt(0)}`;
                    return (
                        <div key={partner.uid} onClick={() => onSelect(partner.uid)} className="flex items-center p-3 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 border-b dark:border-gray-700">
                            <img src={avatar} alt={partner.profile.name} className="w-12 h-12 rounded-full mr-4" />
                            <div className="flex-grow overflow-hidden">
                                <p className="font-bold truncate">{partner.profile.name}</p>
                                <p className="text-sm text-gray-500 dark:text-gray-400 truncate">{lastMessage.text}</p>
                            </div>
                        </div>
                    );
                })
            )}
        </div>
    );
};


const PrivateMessagesOverlay: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { modal, currentUser, users, privateMessages } = state;
    const [isVisible, setIsVisible] = useState(false);
    const [activeChatPartnerId, setActiveChatPartnerId] = useState<string | null>(null);
    
    const isOpen = modal.type === 'private-messages';

    useEffect(() => {
        if (isOpen) {
            setIsVisible(true);
            if (modal.data?.targetUserId) {
                setActiveChatPartnerId(modal.data.targetUserId);
            }
        } else {
            setActiveChatPartnerId(null);
        }
    }, [isOpen, modal.data]);

    const handleClose = () => {
        dispatch({ type: 'HIDE_MODAL' });
    };

    const onAnimationEnd = () => {
        if (!isOpen) {
            setIsVisible(false);
        }
    };
    
    const conversations = useMemo(() => {
        if (!currentUser) return [];
        const conversationsMap = new Map<string, { partnerId: string, lastMessage: PrivateMessage }>();

        Object.values(privateMessages).flat().forEach(msg => {
            const partnerId = msg.senderId === currentUser.uid ? msg.receiverId : msg.senderId;
            const existing = conversationsMap.get(partnerId);
            if (!existing || new Date(msg.timestamp) > new Date(existing.lastMessage.timestamp)) {
                conversationsMap.set(partnerId, { partnerId, lastMessage: msg });
            }
        });

        return Array.from(conversationsMap.values())
            .map(({ partnerId, lastMessage }) => ({
                partner: users[partnerId],
                lastMessage,
            }))
            .filter(c => c.partner && c.partner.profile)
            .sort((a, b) => new Date(b.lastMessage.timestamp).getTime() - new Date(a.lastMessage.timestamp).getTime());

    }, [privateMessages, users, currentUser]);

    const activePartner = activeChatPartnerId ? users[activeChatPartnerId] : null;

    if (!isVisible) return null;

    return (
        <div 
            className={`chat-overlay fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0'}`}
            onTransitionEnd={onAnimationEnd}
            onClick={handleClose}
        >
            <div 
                className={`chat-container absolute bottom-0 left-0 right-0 bg-white dark:bg-gray-800 rounded-t-2xl shadow-lg h-3/4 flex flex-col transform transition-transform duration-300 ${isOpen ? 'translate-y-0' : 'translate-y-full'}`}
                onClick={e => e.stopPropagation()}
            >
                {activePartner && activePartner.profile ? (
                    <ChatView partner={activePartner} onBack={() => setActiveChatPartnerId(null)} />
                ) : (
                    <>
                        <div className="p-4 border-b dark:border-gray-700 flex justify-between items-center">
                            <h3 className="text-lg font-bold">Pesan Pribadi</h3>
                            <button onClick={handleClose} className="text-gray-500 hover:text-gray-800 dark:hover:text-gray-200" aria-label="Tutup Pesan">
                                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                            </button>
                        </div>
                        <ConversationListView conversations={conversations} onSelect={setActiveChatPartnerId} />
                    </>
                )}
            </div>
        </div>
    );
};

export default PrivateMessagesOverlay;