import React, { useState, useEffect, useRef } from 'react';
import { useAppContext } from '../../context/AppContext';
import type { Message } from '../../types';
import { AI_USER } from '../../constants';

const RoomChatOverlay: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { modal, currentUser, currentPresence, publicMessages, users } = state;
    const [isVisible, setIsVisible] = useState(false);
    const [newMessage, setNewMessage] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);
    
    const isOpen = modal.type === 'room-chat';
    const currentChannelId = currentPresence?.channelId;
    const messages = currentChannelId ? publicMessages[currentChannelId] || [] : [];

    useEffect(() => {
        if (isOpen) {
            setIsVisible(true);
        }
    }, [isOpen]);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages]);

    const handleClose = () => {
        dispatch({ type: 'HIDE_MODAL' });
    };

    const onAnimationEnd = () => {
        if (!isOpen) {
            setIsVisible(false);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (newMessage.trim() && currentUser && currentChannelId) {
            const message: Message = {
                id: `msg-${Date.now()}`,
                senderId: currentUser.uid,
                text: newMessage.trim(),
                timestamp: new Date().toISOString(),
            };
            dispatch({ type: 'ADD_PUBLIC_MESSAGE', payload: { channelId: currentChannelId, message } });
            setNewMessage('');
        }
    };
    
    if (!isVisible) return null;

    return (
        <div 
            className={`chat-overlay fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0'}`}
            onTransitionEnd={onAnimationEnd}
            onClick={handleClose}
        >
            <div 
                className={`chat-container absolute bottom-0 left-0 right-0 bg-white dark:bg-gray-800 rounded-t-2xl shadow-lg h-3/4 flex flex-col transform transition-transform duration-300 ${isOpen ? 'translate-y-0' : 'translate-y-full'}`}
                onClick={e => e.stopPropagation()}
            >
                <div className="p-4 border-b dark:border-gray-700 flex justify-between items-center">
                    <h3 className="text-lg font-bold">Obrolan Room</h3>
                    <button onClick={handleClose} className="text-gray-500 hover:text-gray-800 dark:hover:text-gray-200" aria-label="Tutup Obrolan">
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </div>
                <div className="flex-grow p-4 overflow-y-auto custom-scrollbar">
                    {messages.length === 0 ? (
                         <p className="text-center text-gray-500 p-4">Belum ada pesan. Mulai percakapan!</p>
                    ) : (
                        messages.map(msg => {
                            const sender = users[msg.senderId];
                            const isSelf = msg.senderId === currentUser?.uid;
                            const isAI = msg.senderId === AI_USER.uid;
                            const avatar = (sender?.profile?.photos?.[0]) || 'https://placehold.co/40x40/16a34a/ffffff?text=SN';

                            return (
                                <div key={msg.id} className={`flex items-start gap-2.5 mb-4 ${isSelf ? 'justify-end' : ''}`}>
                                    {!isSelf && <img className="w-8 h-8 rounded-full" src={avatar} alt={`${sender?.profile?.name || 'User'} avatar`} />}
                                    <div className={`flex flex-col gap-1 ${isSelf ? 'items-end' : ''}`}>
                                        <span className="text-sm font-semibold text-gray-900 dark:text-white">{sender?.profile?.name || 'Unknown'}</span>
                                        <div className={`leading-1.5 p-2 border-gray-200 ${isSelf ? 'bg-green-100 dark:bg-green-800 rounded-s-xl rounded-ee-xl' : isAI ? 'bg-blue-100 dark:bg-blue-900/50 rounded-e-xl rounded-es-xl' : 'bg-gray-100 dark:bg-gray-700 rounded-e-xl rounded-es-xl'}`}>
                                            <p className="text-sm font-normal text-gray-900 dark:text-white">{msg.text}</p>
                                        </div>
                                    </div>
                                    {isSelf && <img className="w-8 h-8 rounded-full" src={avatar} alt="My avatar" />}
                                </div>
                            )
                        })
                    )}
                     <div ref={messagesEndRef} />
                </div>
                <form onSubmit={handleSubmit} className="p-4 border-t dark:border-gray-700 flex gap-2">
                    <input type="text" value={newMessage} onChange={e => setNewMessage(e.target.value)} className="flex-grow p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:border-gray-600" placeholder="Ketik pesan..." autoComplete="off" />
                    <button type="submit" className="bg-green-600 text-white p-3 rounded-lg hover:bg-green-700 flex items-center justify-center" aria-label="Kirim Pesan">
                         <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path></svg>
                    </button>
                </form>
            </div>
        </div>
    );
};

export default RoomChatOverlay;