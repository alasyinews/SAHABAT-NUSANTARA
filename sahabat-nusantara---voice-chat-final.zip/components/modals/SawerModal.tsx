import React from 'react';
import { useAppContext } from '../../context/AppContext';
import Modal from '../ui/Modal';
import type { User } from '../../types';
import { SAWER_GIFTS } from '../../constants';

const SawerModal: React.FC = () => {
    const { state, dispatch, showToast, triggerCoinAnimation } = useAppContext();
    const { modal, currentUser } = state;

    const isOpen = modal.type === 'sawer';
    const targetUser = modal.data as User | undefined;

    const handleClose = () => {
        dispatch({ type: 'HIDE_MODAL' });
    };

    const handleSendGift = (cost: number, giftName: string) => {
        if (!currentUser || !targetUser) return;
        
        const myCoins = currentUser.profile.coins;
        if (myCoins < cost) {
            showToast('Koin Anda tidak cukup!');
            return;
        }

        // Deduct from sender
        dispatch({
            type: 'UPDATE_CURRENT_USER_PROFILE',
            payload: { coins: myCoins - cost }
        });

        // Add to receiver
        const receiver = state.users[targetUser.uid];
        if (receiver) {
            const updatedReceiverProfile = { ...receiver.profile, coins: receiver.profile.coins + cost };
            dispatch({ type: 'ADD_USER', payload: { ...receiver, profile: updatedReceiverProfile } });
        }
        
        showToast(`Anda mengirim ${giftName} ke ${targetUser.profile.name}!`);
        triggerCoinAnimation(currentUser.uid, targetUser.uid);
        handleClose();
    };

    if (!targetUser || !currentUser || !targetUser.profile) return null;

    return (
        <Modal isOpen={isOpen} onClose={handleClose} contentClasses="p-6 text-center">
            <h3 className="text-xl font-bold">Kirim Hadiah untuk <span className="text-green-600 dark:text-green-400">{targetUser.profile.name}</span></h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">Saldo Anda: <span className="font-bold">{currentUser.profile.coins}</span> Koin</p>
            <div className="grid grid-cols-3 gap-3 my-4">
                {SAWER_GIFTS.map(gift => (
                    <button
                        key={gift.id}
                        onClick={() => handleSendGift(gift.cost, gift.name)}
                        disabled={currentUser.profile.coins < gift.cost}
                        className="sawer-gift-btn flex flex-col items-center p-2 border dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600"
                    >
                        <span className="text-3xl">{gift.icon}</span>
                        <span className="text-xs font-semibold">{gift.name}</span>
                        <span className="text-xs text-yellow-500">{gift.cost}</span>
                    </button>
                ))}
            </div>
            <button onClick={handleClose} className="mt-2 text-sm text-gray-500 hover:text-gray-700">Batal</button>
        </Modal>
    );
};

export default SawerModal;