import React from 'react';
import { useAppContext } from '../../context/AppContext';
import Modal from '../ui/Modal';
import type { User, Presence } from '../../types';

const UserProfileModal: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { modal, currentUser } = state;

    const isOpen = modal.type === 'user-profile';
    const user = (modal.data as {uid: string, profile: User['profile'], presence: Presence}) || null;

    if (!user || !user.profile) return null;

    const isSelf = user.uid === currentUser?.uid;

    const handleClose = () => {
        dispatch({ type: 'HIDE_MODAL' });
    };
    
    const openEditModal = () => {
        handleClose();
        setTimeout(() => dispatch({ type: 'SHOW_MODAL', payload: { type: 'edit-profile' } }), 300);
    };

    const openSawerModal = () => {
        handleClose();
        setTimeout(() => dispatch({ type: 'SHOW_MODAL', payload: { type: 'sawer', data: user } }), 300);
    };

    const openPrivateMessage = () => {
        handleClose();
        setTimeout(() => dispatch({ 
            type: 'SHOW_MODAL', 
            payload: { type: 'private-messages', data: { targetUserId: user.uid } }
        }), 300);
    };

    return (
        <Modal isOpen={isOpen} onClose={handleClose} contentClasses="overflow-hidden p-0">
            <button onClick={handleClose} className="absolute top-3 right-3 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 z-10" aria-label="Tutup Profil">
                 <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
            <div className="custom-scrollbar overflow-y-auto max-h-[85vh]">
                <div className="flex overflow-x-auto snap-x snap-mandatory no-scrollbar bg-gray-200 dark:bg-gray-700">
                    {(user.profile.photos && user.profile.photos.length > 0) ? 
                        user.profile.photos.map((p, i) => <img key={`${i}-${p.slice(-10)}`} src={p} className="w-full h-64 object-cover flex-shrink-0 snap-center" alt={`Foto profil ${i+1}`} />) :
                        <div className="w-full h-64 flex items-center justify-center text-gray-400">Tidak ada foto</div>
                    }
                </div>
                <div className="p-5">
                    <h3 className="text-2xl font-bold">{user.profile.name}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 flex items-center gap-1.5">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0zM15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                        <span>{user.profile.address}</span>
                    </p>
                    <p className="text-gray-600 dark:text-gray-300 mt-4 text-sm">{user.profile.bio || "Pengguna ini belum menulis biodata."}</p>
                </div>
                <div className="px-5 pb-5 grid grid-cols-2 gap-2">
                    {isSelf ? (
                        <button onClick={openEditModal} className="col-span-2 w-full bg-green-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-green-700">Edit Profil</button>
                    ) : (
                        <>
                            <button onClick={openPrivateMessage} className="w-full bg-blue-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-600">Kirim Pesan</button>
                            <button onClick={openSawerModal} className="w-full bg-yellow-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-yellow-600">Sawer</button>
                        </>
                    )}
                </div>
            </div>
        </Modal>
    );
};

export default UserProfileModal;