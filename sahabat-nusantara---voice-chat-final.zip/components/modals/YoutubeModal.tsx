import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useAppContext } from '../../context/AppContext';
import Modal from '../ui/Modal';
import { getYoutubeVideoId } from '../../utils/helpers';

const MIN_WIDTH = 320;
const MIN_HEIGHT = 250;

const YoutubeModal: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { modal } = state;
    const [url, setUrl] = useState('');
    const [videoId, setVideoId] = useState<string | null>(null);

    const isOpen = modal.type === 'youtube';

    // State for draggable/resizable behavior
    const modalRef = useRef<HTMLDivElement>(null);
    const [position, setPosition] = useState({ x: 0, y: 0 });
    const [size, setSize] = useState({ width: 560, height: 425 });
    const [isDragging, setIsDragging] = useState(false);
    const [isResizing, setIsResizing] = useState(false);

    const dragInfo = useRef({ offsetX: 0, offsetY: 0 });
    const resizeInfo = useRef({ startX: 0, startY: 0, startWidth: 0, startHeight: 0 });

    // Center modal on initial open
    useEffect(() => {
        if (isOpen) {
            setPosition({
                x: Math.max(0, (window.innerWidth - size.width) / 2),
                y: Math.max(0, (window.innerHeight - size.height) / 2),
            });
        } else {
            setVideoId(null);
            setUrl('');
        }
    }, [isOpen]); // Intentionally not including size to avoid recentering on resize

    const handleClose = () => {
        dispatch({ type: 'HIDE_MODAL' });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const id = getYoutubeVideoId(url);
        setVideoId(id);
    };

    const getCoords = (e: MouseEvent | TouchEvent): { x: number, y: number } => {
        if ('touches' in e) {
            return { x: e.touches[0].clientX, y: e.touches[0].clientY };
        }
        return { x: e.clientX, y: e.clientY };
    };

    const handleDragStart = useCallback((e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
        if (!modalRef.current) return;
        setIsDragging(true);
        const rect = modalRef.current.getBoundingClientRect();
        const coords = getCoords(e.nativeEvent);
        dragInfo.current = {
            offsetX: coords.x - rect.left,
            offsetY: coords.y - rect.top,
        };
        e.preventDefault();
    }, []);

    const handleResizeStart = useCallback((e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
        setIsResizing(true);
        const coords = getCoords(e.nativeEvent);
        resizeInfo.current = {
            startX: coords.x,
            startY: coords.y,
            startWidth: size.width,
            startHeight: size.height,
        };
        e.preventDefault();
    }, [size.width, size.height]);

    const handleMove = useCallback((e: MouseEvent | TouchEvent) => {
        const coords = getCoords(e);
        if (isDragging) {
            setPosition({
                x: coords.x - dragInfo.current.offsetX,
                y: coords.y - dragInfo.current.offsetY,
            });
        }
        if (isResizing) {
            const newWidth = resizeInfo.current.startWidth + (coords.x - resizeInfo.current.startX);
            const newHeight = resizeInfo.current.startHeight + (coords.y - resizeInfo.current.startY);
            setSize({
                width: Math.max(MIN_WIDTH, newWidth),
                height: Math.max(MIN_HEIGHT, newHeight),
            });
        }
    }, [isDragging, isResizing]);

    const handleMoveEnd = useCallback(() => {
        setIsDragging(false);
        setIsResizing(false);
    }, []);

    useEffect(() => {
        if (isDragging || isResizing) {
            window.addEventListener('mousemove', handleMove);
            window.addEventListener('mouseup', handleMoveEnd);
            window.addEventListener('touchmove', handleMove);
            window.addEventListener('touchend', handleMoveEnd);
            return () => {
                window.removeEventListener('mousemove', handleMove);
                window.removeEventListener('mouseup', handleMoveEnd);
                window.removeEventListener('touchmove', handleMove);
                window.removeEventListener('touchend', handleMoveEnd);
            };
        }
    }, [isDragging, isResizing, handleMove, handleMoveEnd]);


    return (
        <Modal 
            isOpen={isOpen} 
            onClose={handleClose} 
            containerClasses="!items-start !justify-start" 
            contentClasses="!p-0 !bg-transparent !border-none !shadow-none !transform-none !w-auto !max-w-none !max-h-none"
        >
            <div
                ref={modalRef}
                className="rounded-lg shadow-xl flex flex-col overflow-hidden bg-gray-800"
                style={{
                    position: 'absolute',
                    width: `${size.width}px`,
                    height: `${size.height}px`,
                    transform: `translate(${position.x}px, ${position.y}px)`,
                    minWidth: `${MIN_WIDTH}px`,
                    minHeight: `${MIN_HEIGHT}px`,
                    userSelect: (isDragging || isResizing) ? 'none' : 'auto',
                }}
            >
                <div 
                    onMouseDown={handleDragStart}
                    onTouchStart={handleDragStart}
                    className="bg-gray-900 p-2 flex justify-between items-center cursor-move flex-shrink-0"
                >
                    <h3 className="text-white text-sm font-bold select-none">YouTube Karaoke</h3>
                    <button onClick={handleClose} className="text-gray-400 hover:text-white" aria-label="Tutup YouTube">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </div>
                <form onSubmit={handleSubmit} className="p-2 bg-gray-900 border-y border-gray-700 flex-shrink-0">
                    <div className="flex gap-2">
                        <input 
                            type="text" 
                            value={url}
                            onChange={(e) => setUrl(e.target.value)}
                            className="flex-grow bg-gray-700 text-white border border-gray-600 rounded-md px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-green-500" 
                            placeholder="Tempel link YouTube di sini..."
                        />
                        <button type="submit" className="bg-green-600 text-white px-3 rounded-md hover:bg-green-700">Putar</button>
                    </div>
                </form>
                <div className="flex-grow bg-black relative">
                    {videoId ? (
                        <iframe 
                            className="w-full h-full" 
                            src={`https://www.youtube.com/embed/${videoId}?autoplay=1`}
                            title="YouTube video player"
                            frameBorder="0" 
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                            allowFullScreen
                            style={{ pointerEvents: (isDragging || isResizing) ? 'none' : 'auto' }}
                        ></iframe>
                    ) : (
                        <div className="w-full h-full flex items-center justify-center text-gray-400 select-none">
                            Tempel link untuk memulai karaoke
                        </div>
                    )}
                </div>
                <div 
                    onMouseDown={handleResizeStart}
                    onTouchStart={handleResizeStart}
                    className="absolute bottom-0 right-0 w-4 h-4 cursor-se-resize"
                    style={{ zIndex: 10 }}
                >
                    <svg className="w-full h-full text-gray-500 opacity-70" viewBox="0 0 16 16">
                        <path d="M15 16V1M16 15H1" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                    </svg>
                </div>
            </div>
        </Modal>
    );
};

export default YoutubeModal;
