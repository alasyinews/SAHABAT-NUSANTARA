import React, { useState } from 'react';
import type { AppStatus } from '../../types';
import { useAppContext } from '../../context/AppContext';
import PasswordInput from '../ui/PasswordInput';
import { ADMIN_USER } from '../../constants';

interface AdminLoginPageProps {
    setAppStatus: (status: AppStatus) => void;
}

const AdminLoginPage: React.FC<AdminLoginPageProps> = ({ setAppStatus }) => {
    const { dispatch } = useAppContext();
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleLogin = () => {
        if (username === ADMIN_USER.profile.username && password === ADMIN_USER.profile.password) {
            dispatch({ type: 'SET_CURRENT_USER', payload: ADMIN_USER });
            dispatch({ type: 'SET_ADMIN_STATUS', payload: true });
            setAppStatus('main');
        } else {
            setError('Username atau kata sandi admin salah.');
            setPassword('');
            setTimeout(() => setError(''), 3000);
        }
    };

    return (
        <div className="page p-6 flex flex-col justify-center items-center h-full text-center">
            <h1 className="text-3xl font-bold dark:text-gray-100">Login Admin</h1>
            <p className="text-gray-500 dark:text-gray-400 mt-2 mb-8">Masukkan kredensial admin untuk melanjutkan.</p>
            
            <div className="w-full max-w-xs mb-4">
                <div className="space-y-4">
                    <div>
                        <label htmlFor="admin-username" className="sr-only">Username Admin</label>
                        <input
                            id="admin-username"
                            type="text"
                            value={username}
                            onChange={(e) => { setUsername(e.target.value); if(error) setError(''); }}
                            onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                            placeholder="Username Admin"
                            className="block w-full px-4 py-3 bg-gray-50 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 transition dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 text-center"
                            autoComplete="username"
                        />
                    </div>
                    <div>
                        <label htmlFor="admin-password" className="sr-only">Kata Sandi Admin</label>
                        <PasswordInput
                            id="admin-password"
                            value={password}
                            onChange={(e) => { setPassword(e.target.value); if(error) setError(''); }}
                            onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                            placeholder="Kata Sandi Admin"
                            className="block w-full px-4 py-3 bg-gray-50 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 transition dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 text-center"
                            buttonClassName="hover:text-green-600"
                        />
                    </div>
                </div>
                <p className="text-red-500 text-sm mt-2 h-5">{error}</p>
            </div>

            <button
                onClick={handleLogin}
                className="w-full max-w-xs bg-green-700 text-white font-bold py-3 px-4 rounded-lg hover:bg-green-800 focus:outline-none focus:ring-4 focus:ring-green-300 transition-all duration-300 transform hover:scale-105"
            >
                Masuk
            </button>
             <button
                onClick={() => setAppStatus('login')}
                className="mt-4 text-sm text-gray-500 dark:text-gray-400 hover:underline"
            >
                Kembali ke Login Pengguna
            </button>
        </div>
    );
};

export default AdminLoginPage;