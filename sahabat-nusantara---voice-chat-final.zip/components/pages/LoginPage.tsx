import React, { useState, useEffect } from 'react';
import type { AppStatus, User } from '../../types';
import { useAppContext } from '../../context/AppContext';
import PasswordInput from '../ui/PasswordInput';

interface LoginPageProps {
    setAppStatus: (status: AppStatus) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ setAppStatus }) => {
    const { dispatch } = useAppContext();
    const [name, setName] = useState('');
    const [address, setAddress] = useState('');
    const [gender, setGender] = useState<'Perempuan' | 'Laki-laki' | 'Lainnya' | ''>('');
    const [password, setPassword] = useState('');
    const [isFormValid, setIsFormValid] = useState(false);
    const [locationStatus, setLocationStatus] = useState('');

    useEffect(() => {
        setIsFormValid(name.trim() !== '' && address.trim() !== '' && gender !== '' && password.trim() !== '');
    }, [name, address, gender, password]);
    
    useEffect(() => {
        let isMounted = true;
        const getLocation = async () => {
            if (!isMounted) return;
            setLocationStatus('Mencari lokasi...');
            try {
                const response = await fetch('https://ipapi.co/json/');
                if (!isMounted) return;
                if (!response.ok) throw new Error('Gagal mendapatkan data lokasi.');
                const data = await response.json();
                if (!isMounted) return;
                const locationString = `${data.city}, ${data.country_name}`;
                setAddress(locationString);
                setLocationStatus(`Lokasi ditemukan: ${data.city}`);
            } catch (error) {
                if (!isMounted) return;
                console.error("Location fetch error:", error);
                setLocationStatus('Gagal mendeteksi lokasi. Periksa koneksi Anda.');
            }
        };

        getLocation();

        return () => {
            isMounted = false;
        };
    }, []);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!isFormValid) return;

        const newUid = `user-${Date.now()}`;
        const newUser: User = {
            uid: newUid,
            profile: {
                name: name.trim(),
                address: address.trim(),
                gender: gender || 'Tidak ditentukan',
                bio: '',
                photos: [],
                avatarIndex: 0,
                coins: 100,
                isVip: false,
                password: password.trim(),
                createdAt: new Date().toISOString(),
            },
        };

        dispatch({ type: 'SET_CURRENT_USER', payload: newUser });
        setAppStatus('profile-setup');
    };

    return (
        <div className="page p-6 flex flex-col justify-center h-full">
            <div className="text-center mb-10">
                <h1 className="text-4xl font-bold text-green-700 dark:text-green-400">Sahabat Nusantara</h1>
                <p className="text-gray-500 dark:text-gray-400 mt-2">Platform Komunitas Anda</p>
            </div>
            <form onSubmit={handleSubmit} className="space-y-6" noValidate>
                <div>
                    <label htmlFor="nama" className="block text-sm font-medium">Nama Lengkap</label>
                    <input type="text" id="nama" value={name} onChange={(e) => setName(e.target.value)} required className="mt-1 block w-full px-4 py-3 bg-gray-50 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 transition dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400" autoComplete="name" />
                </div>
                <div>
                    <label htmlFor="alamat" className="block text-sm font-medium">Alamat (Otomatis dari IP)</label>
                    <div className="relative mt-1">
                        <input 
                            type="text" 
                            id="alamat" 
                            value={address} 
                            readOnly 
                            required 
                            placeholder="Mendeteksi lokasi..." 
                            className="block w-full px-4 py-3 bg-gray-100 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 transition dark:bg-gray-800 dark:border-gray-600 cursor-default"
                        />
                    </div>
                    <p className="text-xs text-gray-500 mt-1 h-4">{locationStatus}</p>
                </div>
                 <div>
                    <label htmlFor="gender-select" className="block text-sm font-medium">Jenis Kelamin</label>
                    <select
                        id="gender-select"
                        value={gender}
                        onChange={(e) => setGender(e.target.value as 'Perempuan' | 'Laki-laki' | 'Lainnya')}
                        required
                        className={`mt-1 block w-full px-4 py-3 bg-gray-50 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 transition dark:bg-gray-700 dark:border-gray-600 ${!gender ? 'text-gray-500' : 'text-gray-900 dark:text-white'}`}
                    >
                        <option value="" disabled>Pilih jenis kelamin</option>
                        <option value="Laki-laki">Laki-laki</option>
                        <option value="Perempuan">Perempuan</option>
                        <option value="Lainnya">Lainnya</option>
                    </select>
                </div>
                <div>
                    <label htmlFor="password" className="block text-sm font-medium">Kata Sandi</label>
                    <PasswordInput
                         id="password"
                         value={password}
                         onChange={(e) => setPassword(e.target.value)}
                         placeholder="Masukkan kata sandi"
                         wrapperClassName="mt-1"
                         className="block w-full px-4 py-3 pr-10 bg-gray-50 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 transition dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400"
                         buttonClassName="hover:text-green-600"
                    />
                </div>
                <button type="submit" className="w-full text-white font-bold py-3 px-4 rounded-lg btn-3d btn-green-3d text-lg disabled:opacity-50" disabled={!isFormValid}>
                    Daftar
                </button>
            </form>
             <div className="text-center mt-6">
                <button
                    onClick={() => setAppStatus('admin-login')}
                    className="text-sm text-gray-500 dark:text-gray-400 hover:underline"
                >
                    Masuk sebagai Admin
                </button>
            </div>
        </div>
    );
};

export default LoginPage;