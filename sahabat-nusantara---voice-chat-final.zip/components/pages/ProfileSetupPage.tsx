import React, { useState, useEffect } from 'react';
import type { AppStatus } from '../../types';
import { useAppContext } from '../../context/AppContext';
import Modal from '../ui/Modal';
import ProfileFormFields from '../ui/ProfileFormFields';

interface ProfileSetupPageProps {
    setAppStatus: (status: AppStatus) => void;
}

const ProfileSetupPage: React.FC<ProfileSetupPageProps> = ({ setAppStatus }) => {
    const { state, dispatch, showToast } = useAppContext();
    const [photos, setPhotos] = useState<string[]>([]);
    const [bio, setBio] = useState('');
    const [isValid, setIsValid] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
    const [isAgreed, setIsAgreed] = useState(false);

    useEffect(() => {
        setIsValid(photos.length > 0 && bio.trim() !== '');
    }, [photos, bio]);

    const handleFinalSubmit = () => {
        if (!isValid || isLoading) return;

        setIsAuthModalOpen(false);
        setIsLoading(true);

        const newProfile = {
            bio: bio.trim(),
            photos: photos,
        };

        dispatch({ type: 'UPDATE_CURRENT_USER_PROFILE', payload: newProfile });

        // Save to local storage
        if (state.currentUser) {
            const userProfileJson = localStorage.getItem(`sn_user_${state.currentUser.uid}`);
            const profileData = userProfileJson ? JSON.parse(userProfileJson) : {};
            const updatedProfile = { ...profileData, ...state.currentUser.profile, ...newProfile };
            localStorage.setItem(`sn_user_${state.currentUser.uid}`, JSON.stringify(updatedProfile));
            localStorage.setItem('sn_current_uid', state.currentUser.uid);
        }

        setTimeout(() => {
            setIsLoading(false);
            setAppStatus('main');
        }, 1500);
    };
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!isValid || isLoading) return;
        setIsAuthModalOpen(true);
    };

    return (
        <div className="page p-6 flex flex-col justify-center h-full">
            <h2 className="text-2xl font-bold text-center text-green-700 dark:text-green-400 mb-6">Lengkapi Profil Anda</h2>
            <form onSubmit={handleSubmit} noValidate>
                <ProfileFormFields
                    photos={photos}
                    setPhotos={setPhotos}
                    bio={bio}
                    setBio={setBio}
                    currentUser={state.currentUser}
                    showToast={showToast}
                />
                <button type="submit" className="w-full text-white font-bold py-3 px-4 rounded-lg text-lg btn-3d btn-green-3d flex items-center justify-center gap-2 disabled:opacity-50" disabled={!isValid || isLoading}>
                    {isLoading ? (
                        <>
                            <div className="loader" style={{width: '20px', height: '20px', borderWidth: '2px', borderTopColor: 'white'}}></div>
                            <span>Mempersiapkan...</span>
                        </>
                    ) : (
                        <span>Masuk Aplikasi</span>
                    )}
                </button>
                <p className="text-red-500 text-xs text-center mt-2 h-4">{!isValid && photos.length > 0 && 'Harap isi biodata.' || !isValid && bio.trim() && 'Harap unggah foto.'}</p>
            </form>
            
            <Modal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} contentClasses="p-6">
                <h3 className="text-xl font-bold text-center mb-4">Satu Langkah Lagi!</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-5">
                    Dengan melanjutkan, Anda mengonfirmasi bahwa Anda telah membaca, memahami, dan menyetujui 
                    <strong className="text-green-600 dark:text-green-400"> Syarat & Ketentuan</strong> serta 
                    <strong className="text-green-600 dark:text-green-400"> Kebijakan Privasi</strong> aplikasi Sahabat Nusantara.
                </p>
                <div className="flex items-center mb-6 cursor-pointer" onClick={() => setIsAgreed(!isAgreed)}>
                    <input 
                        id="agree-checkbox"
                        type="checkbox" 
                        checked={isAgreed}
                        onChange={(e) => setIsAgreed(e.target.checked)}
                        className="h-4 w-4 text-green-600 border-gray-300 rounded focus:ring-green-500 cursor-pointer"
                    />
                    <label htmlFor="agree-checkbox" className="ml-2 block text-sm text-gray-900 dark:text-gray-200 cursor-pointer">
                        Saya setuju dengan syarat dan ketentuan yang berlaku.
                    </label>
                </div>
                <div className="flex justify-end gap-3">
                    <button
                        type="button"
                        onClick={() => setIsAuthModalOpen(false)}
                        className="px-4 py-2 bg-gray-200 rounded-md hover:bg-gray-300 dark:bg-gray-600 dark:hover:bg-gray-500 font-semibold"
                    >
                        Batal
                    </button>
                    <button
                        type="button"
                        onClick={handleFinalSubmit}
                        disabled={!isAgreed}
                        className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        Lanjutkan & Masuk
                    </button>
                </div>
            </Modal>
        </div>
    );
};

export default ProfileSetupPage;
