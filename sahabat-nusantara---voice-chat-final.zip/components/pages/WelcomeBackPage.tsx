import React, { useState, useEffect } from 'react';
import type { AppStatus } from '../../types';
import { useAppContext } from '../../context/AppContext';

interface WelcomeBackPageProps {
    setAppStatus: (status: AppStatus) => void;
}

const WelcomeBackPage: React.FC<WelcomeBackPageProps> = ({ setAppStatus }) => {
    const { state } = useAppContext();
    const { currentUser } = state;
    const [error, setError] = useState('');

    useEffect(() => {
        if (!currentUser) {
            // Safeguard against missing user data
            setAppStatus('login');
            return;
        }

        if (currentUser.profile.isBanned) {
            setError('Akun Anda telah diblokir. Silakan hubungi admin.');
            return;
        }
    }, [currentUser, setAppStatus]);

    const handleLogin = () => {
        setAppStatus('main');
    };

    if (!currentUser) return null;

    const profile = currentUser.profile;
    const avatarUrl = (profile.photos && profile.photos.length > 0)
        ? profile.photos[profile.avatarIndex || 0]
        : `https://placehold.co/96x96/16a34a/ffffff?text=${profile.name.charAt(0)}`;

    return (
        <div className="page p-6 flex flex-col justify-center items-center h-full text-center">
            <img src={avatarUrl} alt="Avatar Pengguna" className="w-24 h-24 rounded-full object-cover mb-4 border-4 border-green-500 shadow-lg" />
            <h1 className="text-3xl font-bold dark:text-gray-100">Selamat Datang Kembali,</h1>
            <p className="text-2xl text-green-600 dark:text-green-400 font-semibold mb-6">{profile.name}</p>
            
            {error ? (
                <>
                    <p className="text-red-500 font-semibold mt-4">{error}</p>
                     <button
                        onClick={() => {
                            localStorage.removeItem('sn_current_uid');
                            setAppStatus('login');
                        }}
                        className="mt-4 text-sm text-gray-500 dark:text-gray-400 hover:underline"
                    >
                        Masuk dengan akun lain
                    </button>
                </>
            ) : (
                <button
                    onClick={handleLogin}
                    className="w-full max-w-xs mt-6 text-white font-bold py-3 px-4 rounded-lg btn-3d btn-green-3d text-lg"
                >
                    Masuk Aplikasi
                </button>
            )}
        </div>
    );
};

export default WelcomeBackPage;