import React, { useState, useEffect } from 'react';

interface CoinAnimationLayerProps {
  animationTrigger: { key: number; from: string; to: string } | null;
}

interface Coin {
  id: number;
  startX: number;
  startY: number;
  translateX: number;
  translateY: number;
  delay: number;
}

const CoinAnimationLayer: React.FC<CoinAnimationLayerProps> = ({ animationTrigger }) => {
  const [coins, setCoins] = useState<Coin[]>([]);

  useEffect(() => {
    if (!animationTrigger) return;

    const fromEl = document.getElementById(`user-box-${animationTrigger.from}`);
    const toEl = document.getElementById(`user-box-${animationTrigger.to}`);

    if (!fromEl || !toEl) return;

    const fromRect = fromEl.getBoundingClientRect();
    const toRect = toEl.getBoundingClientRect();
    const containerRect = fromEl.closest('#app-container')?.getBoundingClientRect();

    if (!containerRect) return;

    const newCoins: Coin[] = Array.from({ length: 10 }).map((_, i) => {
        const randomOffsetX = (Math.random() - 0.5) * fromRect.width;
        const randomOffsetY = (Math.random() - 0.5) * fromRect.height;

        const startX = fromRect.left - containerRect.left + fromRect.width / 2 + randomOffsetX;
        const startY = fromRect.top - containerRect.top + fromRect.height / 2 + randomOffsetY;
        const endX = toRect.left - containerRect.left + toRect.width / 2;
        const endY = toRect.top - containerRect.top + toRect.height / 2;

        return {
            id: animationTrigger.key + i,
            startX,
            startY,
            translateX: endX - startX,
            translateY: endY - startY,
            delay: i * 50,
        };
    });

    setCoins(prev => [...prev, ...newCoins]);

    setTimeout(() => {
        setCoins(prev => prev.filter(c => c.id < animationTrigger.key));
    }, 2000 + newCoins.length * 50);

  }, [animationTrigger]);

  return (
    <div className="absolute inset-0 pointer-events-none z-[80] overflow-hidden">
      {coins.map(coin => (
        <div
          key={coin.id}
          className="flying-coin"
          style={{
            left: `${coin.startX}px`,
            top: `${coin.startY}px`,
            '--translate-x': `${coin.translateX}px`,
            '--translate-y': `${coin.translateY}px`,
            animation: `fly-coin 1s ease-in ${coin.delay}ms forwards`,
          } as React.CSSProperties}
        >
        </div>
      ))}
    </div>
  );
};

export default CoinAnimationLayer;