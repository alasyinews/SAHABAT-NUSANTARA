
import React, { useEffect, useState } from 'react';

interface ModalProps {
    isOpen: boolean;
    onClose: () => void;
    children: React.ReactNode;
    containerClasses?: string;
    contentClasses?: string;
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, children, containerClasses = '', contentClasses = '' }) => {
    const [isVisible, setIsVisible] = useState(false);

    useEffect(() => {
        if (isOpen) {
            setIsVisible(true);
        } else {
            const timer = setTimeout(() => setIsVisible(false), 300); // match transition duration
            return () => clearTimeout(timer);
        }
    }, [isOpen]);
    
    if (!isVisible) return null;

    return (
        <div 
            className={`modal fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4 transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0'} ${containerClasses}`}
            onClick={onClose}
        >
            <div
                className={`modal-content bg-white dark:bg-gray-800 rounded-2xl shadow-xl w-full max-w-sm mx-auto transform transition-transform duration-300 ${isOpen ? 'scale-100' : 'scale-95'} ${contentClasses}`}
                onClick={(e) => e.stopPropagation()}
            >
                {children}
            </div>
        </div>
    );
};

export default Modal;
