import React, { useState, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import type { User } from '../../types';
import { fileToBase64 } from '../../utils/helpers';

interface ProfileFormFieldsProps {
    photos: string[];
    setPhotos: (updater: (prev: string[]) => string[]) => void;
    bio: string;
    setBio: (bio: string) => void;
    currentUser: User | null;
    showToast: (message: string) => void;
    avatarIndex?: number;
    setAvatarIndex?: (index: number) => void;
}

const ProfileFormFields: React.FC<ProfileFormFieldsProps> = ({
    photos, setPhotos, bio, setBio, currentUser, showToast, avatarIndex, setAvatarIndex
}) => {
    const [isGeneratingBio, setIsGeneratingBio] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handlePhotoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
        const files = Array.from(event.target.files || []).slice(0, 6 - photos.length);
        if (!files.length) return;

        showToast(`Memproses ${files.length} foto...`);
        try {
            const base64Photos = await Promise.all(files.map(fileToBase64));
            setPhotos(prev => [...prev, ...base64Photos]);
        } catch (error) {
            console.error("Error converting files to base64:", error);
            showToast('Gagal memproses foto.');
        }
        if (event.target) {
            event.target.value = '';
        }
    };

    const handleGenerateBio = async () => {
        if (!currentUser || isGeneratingBio) return;
        setIsGeneratingBio(true);
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const prompt = `Buatkan bio singkat dan ramah untuk pengguna aplikasi chat sosial bernama 'Sahabat Nusantara'. Nama pengguna adalah ${currentUser.profile.name}, berasal dari ${currentUser.profile.address}, dan berjenis kelamin ${currentUser.profile.gender}. Bio harus dalam Bahasa Indonesia, terdengar alami dan menarik. Batasi panjangnya sekitar 150 karakter.`;
            
            const response = await ai.models.generateContent({
              model: 'gemini-2.5-flash',
              contents: prompt,
            });

            const generatedBio = response.text.trim();
            setBio(generatedBio);
            showToast('Bio berhasil dibuat dengan AI!');

        } catch (error) {
            console.error("Error generating bio:", error);
            showToast('Gagal membuat bio. Coba lagi nanti.');
        } finally {
            setIsGeneratingBio(false);
        }
    };

    const removePhoto = (indexToRemove: number) => {
        setPhotos(prev => {
            const newPhotos = prev.filter((_, index) => index !== indexToRemove);
            if (setAvatarIndex) {
                if (avatarIndex === indexToRemove) {
                    setAvatarIndex(0);
                } else if (avatarIndex !== undefined && avatarIndex > indexToRemove) {
                    setAvatarIndex(avatarIndex - 1);
                }
            }
            return newPhotos;
        });
    };

    const fileInputId = `shared-photo-upload-${setAvatarIndex ? 'edit' : 'setup'}`;

    return (
        <>
            <div className="mb-6">
                <p className="text-sm font-medium mb-2">Unggah Foto Profil (Maks. 6)</p>
                <div className="grid grid-cols-3 gap-3">
                    {photos.map((photo, index) => (
                        <div 
                            key={`${index}-${photo.slice(-10)}`} 
                            className={`relative w-full h-24 rounded-lg overflow-hidden group ${setAvatarIndex ? 'cursor-pointer' : ''}`}
                            onClick={setAvatarIndex ? () => setAvatarIndex(index) : undefined}
                        >
                            <img src={photo} className="w-full h-full object-cover" alt={`Pratinjau ${index + 1}`} />
                            {setAvatarIndex && index === avatarIndex && (
                                <div className="absolute inset-0 border-4 border-green-500 rounded-lg flex items-center justify-center bg-black bg-opacity-40">
                                     <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg>
                                </div>
                            )}
                            <button 
                                type="button" 
                                onClick={(e) => { e.stopPropagation(); removePhoto(index); }} 
                                className="absolute top-1 right-1 bg-black bg-opacity-60 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs opacity-0 group-hover:opacity-100 z-10"
                                aria-label="Hapus foto"
                            >
                                &times;
                            </button>
                        </div>
                    ))}
                    {photos.length < 6 && (
                         <label htmlFor={fileInputId} className="flex items-center justify-center w-full h-24 bg-gray-100 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:bg-gray-200 transition dark:bg-gray-800 dark:border-gray-600 dark:hover:bg-gray-700">
                            <div className="text-center text-gray-500">
                                <svg className="w-8 h-8 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4"></path></svg>
                                <span className="text-xs">Tambah</span>
                            </div>
                        </label>
                    )}
                    <input type="file" id={fileInputId} ref={fileInputRef} onChange={handlePhotoUpload} accept="image/*" multiple className="hidden"/>
                </div>
                {setAvatarIndex && <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">Klik foto untuk jadi avatar utama.</p>}
            </div>
            <div className="mb-8">
                <div className="flex justify-between items-center mb-1">
                    <label htmlFor="biodata-shared" className="block text-sm font-medium">Biodata Singkat</label>
                    <button 
                        type="button" 
                        onClick={handleGenerateBio}
                        disabled={isGeneratingBio}
                        className="text-xs text-green-600 dark:text-green-400 font-semibold hover:underline flex items-center gap-1 disabled:opacity-50"
                    >
                        {isGeneratingBio ? (
                            <div className="loader" style={{width: '12px', height: '12px', borderWidth: '2px'}}></div>
                        ) : (
                            <svg className="w-4 h-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M9.8,2.3c0.1-0.3,0.4-0.4,0.6-0.2l1.3,0.6c0.2,0.1,0.3,0.3,0.2,0.6L10.6,8.8c-0.1,0.2-0.3,0.3-0.6,0.2l-1.3-0.6   c-0.2-0.1-0.3-0.3-0.2-0.6L9.8,2.3z" /><path d="M15.2,4.8c0.1-0.3,0.4-0.4,0.6-0.2l1.3,0.6c0.2,0.1,0.3,0.3,0.2,0.6l-1.3,5.5c-0.1,0.2-0.3,0.3-0.6,0.2l-1.3-0.6   c-0.2-0.1-0.3-0.3-0.2-0.6L15.2,4.8z" /><path d="M14,11.2c0.3,0.1,0.4,0.4,0.2,0.6l-0.6,1.3c-0.1,0.2-0.3,0.3-0.6,0.2l-5.5-2.6c-0.2-0.1-0.3-0.3-0.2-0.6l0.6-1.3   c0.1-0.2,0.3-0.3,0.6-0.2L14,11.2z" /><path fillRule="evenodd" d="M4.9,3.9C3.6,5.2,3,6.9,3,8.8c0,4.4,3.6,8,8,8c1.9,0,3.7-0.7,5.1-1.9l-1.5-0.7c-1,0.9-2.3,1.4-3.6,1.4   c-3.3,0-6-2.7-6-6c0-1.4,0.5-2.7,1.3-3.7L4.9,3.9z" clipRule="evenodd" /></svg>
                        )}
                        <span>Buat dengan AI</span>
                    </button>
                </div>
                <textarea id="biodata-shared" value={bio} onChange={e => setBio(e.target.value)} rows={4} required className="mt-1 block w-full px-4 py-3 bg-gray-50 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 transition dark:bg-gray-700 dark:border-gray-600" placeholder="Ceritakan sedikit tentang dirimu..."></textarea>
            </div>
        </>
    );
};

export default ProfileFormFields;