
import type { Channel, User } from './types';

export const ADMIN_USER: User = {
    uid: 'admin-bos-sn',
    profile: {
        name: 'Bos SN',
        username: 'Bos_SN',
        password: 'SN1986',
        address: 'Pusat Kendali',
        gender: 'Lainnya',
        bio: 'Mengelola Sahabat Nusantara dari balik layar.',
        photos: [`data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><linearGradient id="admin-grad" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" style="stop-color:%23f59e0b;stop-opacity:1" /><stop offset="100%" style="stop-color:%23facc15;stop-opacity:1" /></linearGradient></defs><rect width="100" height="100" rx="15" fill="url(%23admin-grad)"/><path d="M50 25 L65 40 L50 55 L35 40 Z" fill="none" stroke="white" stroke-width="5"/><path d="M50 55 L50 75" fill="none" stroke="white" stroke-width="5"/><path d="M35 65 L65 65" fill="none" stroke="white" stroke-width="5"/></svg>`],
        avatarIndex: 0,
        coins: 999999,
        isVip: true,
        isBanned: false,
        createdAt: new Date().toISOString(),
    }
};

export const AI_USER: User = {
    uid: 'sahabat-ai',
    profile: {
        name: 'Sahabat AI',
        address: 'Di Awan',
        gender: 'Lainnya',
        bio: 'Saya adalah asisten AI di room ini. Siap membantu!',
        photos: [`data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><linearGradient id="ai-grad" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" style="stop-color:%2316a34a;stop-opacity:1" /><stop offset="100%" style="stop-color:%234ade80;stop-opacity:1" /></linearGradient></defs><rect width="100" height="100" rx="15" fill="url(%23ai-grad)"/><path d="M30,70 L40,50 L50,70 M40,50 L50,30" stroke="white" stroke-width="6" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M55,35 C60,25 70,25 75,35 C80,45 70,55 65,65 C60,75 50,75 55,65 C60,55 70,45 75,55" stroke="white" stroke-width="5" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>`],
        avatarIndex: 0,
        coins: 0,
        isVip: true,
        isBanned: false,
        createdAt: new Date().toISOString(),
    }
};

export const ICONS = {
    micOn: `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"></path></svg>`,
    micOff: `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3zM2 2l20 20"></path></svg>`,
    speakerOn: `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"></path></svg>`,
    speakerOff: `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15zM17 14l-4-4m0 4l4-4"></path></svg>`,
};

export const MOCK_CHANNELS: Channel[] = [
    { id: 'ruang-santai', name: 'Ruang Santai', mode: 'talk' },
    { id: 'debat-kusir', name: 'Debat Kusir', mode: 'talk' },
    { id: 'karaoke-night', name: 'Karaoke Night', mode: 'karaoke' },
];

export const MOCK_USERS: User[] = [
    {
        uid: 'user-budi',
        profile: {
            name: 'Budi Santoso', address: 'Surabaya, Indonesia', gender: 'Laki-laki', bio: 'Suka ngopi dan diskusi santai.',
            photos: ['https://picsum.photos/seed/budi/400/400'], avatarIndex: 0, coins: 250, isVip: true, createdAt: new Date().toISOString()
        }
    },
    {
        uid: 'user-citra',
        profile: {
            name: 'Citra Lestari', address: 'Bandung, Indonesia', gender: 'Perempuan', bio: 'Penggemar musik indie dan film klasik.',
            photos: ['https://picsum.photos/seed/citra/400/400'], avatarIndex: 0, coins: 120, isVip: false, createdAt: new Date().toISOString()
        }
    },
    {
        uid: 'user-doni',
        profile: {
            name: 'Doni Firmansyah', address: 'Medan, Indonesia', gender: 'Laki-laki', bio: 'Hobi main gitar dan traveling.',
            photos: ['https://picsum.photos/seed/doni/400/400'], avatarIndex: 0, coins: 500, isVip: false, createdAt: new Date().toISOString()
        }
    },
     {
        uid: 'user-eka',
        profile: {
            name: 'Eka Putri', address: 'Makassar, Indonesia', gender: 'Perempuan', bio: 'Pecinta kuliner dan buku.',
            photos: ['https://picsum.photos/seed/eka/400/400'], avatarIndex: 0, coins: 80, isVip: false, createdAt: new Date().toISOString()
        }
    },
     {
        uid: 'user-fitri',
        profile: {
            name: 'Fitri Handayani', address: 'Yogyakarta, Indonesia', gender: 'Perempuan', bio: 'Seniman dan aktivis sosial.',
            photos: ['https://picsum.photos/seed/fitri/400/400'], avatarIndex: 0, coins: 1500, isVip: true, createdAt: new Date().toISOString()
        }
    },
     {
        uid: 'user-gita',
        profile: {
            name: 'Gita Wirawan', address: 'Semarang, Indonesia', gender: 'Perempuan', bio: 'Mahasiswi teknik informatika.',
            photos: ['https://picsum.photos/seed/gita/400/400'], avatarIndex: 0, coins: 30, isVip: false, createdAt: new Date().toISOString()
        }
    },
];

export const SAWER_GIFTS = [
  { id: 'kopi', name: 'Kopi', cost: 10, icon: '☕️' },
  { id: 'bunga', name: 'Bunga', cost: 25, icon: '🌹' },
  { id: 'pizza', name: 'Pizza', cost: 50, icon: '🍕' },
  { id: 'roket', name: 'Roket', cost: 100, icon: '🚀' },
  { id: 'berlian', name: 'Berlian', cost: 250, icon: '💎' },
  { id: 'paus', name: 'Paus', cost: 500, icon: '🐳' },
];