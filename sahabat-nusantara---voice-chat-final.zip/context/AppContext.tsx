
import React, { createContext, useContext, Dispatch } from 'react';
import type { AppState, AppAction, AppStatus, Profile } from '../types';
import { MOCK_CHANNELS, MOCK_USERS, AI_USER, ADMIN_USER } from '../constants';

const mockUsersRecord = MOCK_USERS.reduce((acc, user) => {
    acc[user.uid] = user;
    return acc;
}, {} as Record<string, any>);
mockUsersRecord[AI_USER.uid] = AI_USER; // Add AI user to the record
mockUsersRecord[ADMIN_USER.uid] = ADMIN_USER; // Add Admin user


const mockPresences = MOCK_USERS.reduce((acc, user, index) => {
    acc[user.uid] = {
        uid: user.uid,
        isOnline: true,
        channelId: MOCK_CHANNELS[index % MOCK_CHANNELS.length].id,
        isTalking: false,
        isMicMuted: false,
        isDeafened: false,
    };
    return acc;
}, {} as Record<string, any>);

mockPresences[AI_USER.uid] = {
    uid: AI_USER.uid,
    isOnline: true,
    channelId: MOCK_CHANNELS[0]?.id || null,
    isTalking: false,
    isMicMuted: true,
    isDeafened: true,
};

const savedChannelsJSON = localStorage.getItem('sn_channels');
const initialChannels = savedChannelsJSON ? JSON.parse(savedChannelsJSON) : MOCK_CHANNELS;


export const initialState: AppState = {
    currentUser: null,
    currentPresence: null,
    settings: {
        theme: 'light',
        pttMode: 'toggle',
    },
    users: mockUsersRecord,
    presences: mockPresences,
    channels: initialChannels,
    publicMessages: {},
    privateMessages: {},
    modal: { type: null },
    isAdmin: false,
    currentChannelIndex: 0,
};

export const appReducer = (state: AppState, action: AppAction): AppState => {
    switch (action.type) {
        case 'SET_CURRENT_USER':
            const presence = action.payload ? {
                uid: action.payload.uid,
                isOnline: true,
                channelId: state.channels[0]?.id || null,
                isTalking: false,
                isMicMuted: false,
                isDeafened: false,
            } : null;
            return {
                ...state,
                currentUser: action.payload,
                currentPresence: presence,
                presences: action.payload ? { ...state.presences, [action.payload.uid]: presence! } : state.presences,
            };
        case 'UPDATE_CURRENT_USER_PROFILE':
            if (!state.currentUser) return state;
            const updatedProfile = { ...state.currentUser.profile, ...action.payload };
            const updatedUser = { ...state.currentUser, profile: updatedProfile };
            return {
                ...state,
                currentUser: updatedUser,
                users: { ...state.users, [state.currentUser.uid]: updatedUser },
            };
        case 'SET_PRESENCE':
            return { ...state, currentPresence: action.payload };
        case 'SET_SETTINGS':
            return { ...state, settings: { ...state.settings, ...action.payload } };
        case 'ADD_USER':
            return { ...state, users: { ...state.users, [action.payload.uid]: action.payload } };
        case 'UPDATE_USER_PRESENCE':
            const { uid, ...presenceUpdate } = action.payload;
            if (!state.presences[uid]) return state;
            return {
                ...state,
                presences: {
                    ...state.presences,
                    [uid]: { ...state.presences[uid], ...presenceUpdate },
                },
                currentPresence: uid === state.currentUser?.uid ? { ...state.currentPresence!, ...presenceUpdate } : state.currentPresence,
            };
        case 'ADD_CHANNEL':
            const newChannelsAfterAdd = [...state.channels, action.payload];
            localStorage.setItem('sn_channels', JSON.stringify(newChannelsAfterAdd));
            return { ...state, channels: newChannelsAfterAdd };
        case 'SET_CHANNEL_MODE':
            return {
                ...state,
                channels: state.channels.map(ch =>
                    ch.id === action.payload.channelId ? { ...ch, mode: action.payload.mode } : ch
                ),
            };
        case 'ADD_PUBLIC_MESSAGE':
            const { channelId, message } = action.payload;
            const newMessages = [...(state.publicMessages[channelId] || []), message];
            return {
                ...state,
                publicMessages: { ...state.publicMessages, [channelId]: newMessages },
            };
        case 'ADD_PRIVATE_MESSAGE':
            const { conversationId, message: privateMessage } = action.payload;
            const newPrivateMessages = [...(state.privateMessages[conversationId] || []), privateMessage];
            return {
                ...state,
                privateMessages: { ...state.privateMessages, [conversationId]: newPrivateMessages },
            };
        case 'SHOW_MODAL':
            return { ...state, modal: action.payload };
        case 'HIDE_MODAL':
            return { ...state, modal: { type: null } };
        case 'SET_ADMIN_STATUS':
            return { ...state, isAdmin: action.payload };
        case 'ADMIN_UPDATE_USER_PROFILE':
            const { uid: userId, data } = action.payload;
            if (!state.users[userId]) return state;

            const updatedUserProfile = { ...state.users[userId].profile, ...data };
            const updatedUserForAdmin = { ...state.users[userId], profile: updatedUserProfile };
            
            localStorage.setItem(`sn_user_${userId}`, JSON.stringify(updatedUserForAdmin.profile));

            const newUsers = { ...state.users, [userId]: updatedUserForAdmin };
            const newCurrentUser = state.currentUser?.uid === userId ? updatedUserForAdmin : state.currentUser;

            return {
                ...state,
                users: newUsers,
                currentUser: newCurrentUser,
            };
        case 'SET_CURRENT_CHANNEL_INDEX':
            if (!state.currentUser || !state.currentPresence) return state;

            if (!state.isAdmin) {
                const targetChannel = state.channels[action.payload];
                if (targetChannel?.isLocked) {
                    return state;
                }
            }
            
            const newChannelIdFromIndex = state.channels[action.payload]?.id || null;
            if (state.currentPresence.channelId === newChannelIdFromIndex) return state;

            const oldChannelId = state.currentPresence.channelId;
            const oldChannel = state.channels.find(ch => ch.id === oldChannelId);
            let updatedChannels = [...state.channels];
            let updatedPresences = { ...state.presences };
            let finalNewChannelIndex = action.payload;

            if (oldChannel && oldChannel.isTemporary && oldChannel.creatorId === state.currentUser.uid) {
                const otherChannels = state.channels.filter(ch => ch.id !== oldChannelId);
                let targetChannelId = MOCK_CHANNELS[0]?.id || null;

                if (otherChannels.length > 0) {
                    const channelUserCounts = otherChannels.map(channel => ({
                        id: channel.id,
                        count: Object.values(state.presences).filter(p => p.channelId === channel.id && p.uid !== state.currentUser?.uid).length,
                    }));
                    if (channelUserCounts.length > 0) {
                        const mostPopulatedChannel = channelUserCounts.reduce((max, current) => current.count > max.count ? current : max);
                        targetChannelId = mostPopulatedChannel.id;
                    }
                }

                if (targetChannelId) {
                    const usersToMove = Object.keys(updatedPresences).filter(
                        uid => updatedPresences[uid].channelId === oldChannelId && uid !== state.currentUser.uid
                    );
                    usersToMove.forEach(uid => {
                        updatedPresences[uid] = { ...updatedPresences[uid], channelId: targetChannelId };
                    });
                }
                
                updatedChannels = updatedChannels.filter(ch => ch.id !== oldChannelId);
                localStorage.setItem('sn_channels', JSON.stringify(updatedChannels));
                
                const newChannelForCreator = state.channels[action.payload];
                finalNewChannelIndex = newChannelForCreator ? updatedChannels.findIndex(ch => ch.id === newChannelForCreator.id) : 0;
                if (finalNewChannelIndex === -1) finalNewChannelIndex = 0;
            }
            
            const creatorNewChannelId = updatedChannels[finalNewChannelIndex]?.id || null;
            const updatedCreatorPresence = { ...state.currentPresence, channelId: creatorNewChannelId };
            updatedPresences[state.currentUser.uid] = updatedCreatorPresence;

            return {
                ...state,
                currentChannelIndex: finalNewChannelIndex,
                currentPresence: updatedCreatorPresence,
                presences: updatedPresences,
                channels: updatedChannels,
            };
        case 'REORDER_CHANNELS': {
            const { startIndex, endIndex } = action.payload;
            const newChannels = Array.from(state.channels);
            const [removed] = newChannels.splice(startIndex, 1);
            newChannels.splice(endIndex, 0, removed);
            
            const currentChannelId = state.channels[state.currentChannelIndex].id;
            const newCurrentChannelIndex = newChannels.findIndex(ch => ch.id === currentChannelId);
            
            localStorage.setItem('sn_channels', JSON.stringify(newChannels));

            return { 
                ...state, 
                channels: newChannels,
                currentChannelIndex: newCurrentChannelIndex
            };
        }
        case 'ADMIN_DELETE_USER': {
            const { uid: uidToDelete } = action.payload;
            const { [uidToDelete]: deletedUser, ...remainingUsers } = state.users;
            const { [uidToDelete]: deletedPresence, ...remainingPresences } = state.presences;
            localStorage.removeItem(`sn_user_${uidToDelete}`);

            const newCurrentUser = state.currentUser?.uid === uidToDelete ? null : state.currentUser;
            if (state.currentUser?.uid === uidToDelete) {
                localStorage.removeItem('sn_current_uid');
            }
            
            // Clean up private messages involving the deleted user
            const newPrivateMessages = { ...state.privateMessages };
            for (const conversationId in newPrivateMessages) {
                if (conversationId.includes(uidToDelete)) {
                    delete newPrivateMessages[conversationId];
                }
            }

            return {
                ...state,
                users: remainingUsers,
                presences: remainingPresences,
                privateMessages: newPrivateMessages,
                currentUser: newCurrentUser,
                currentPresence: newCurrentUser ? state.currentPresence : null,
                isAdmin: !!newCurrentUser && state.isAdmin,
            };
        }
        case 'ADMIN_EDIT_CHANNEL': {
            const updatedChannel = action.payload;
            const newChannels = state.channels.map(ch => ch.id === updatedChannel.id ? updatedChannel : ch);
            localStorage.setItem('sn_channels', JSON.stringify(newChannels));
            return { ...state, channels: newChannels };
        }
        case 'ADMIN_DELETE_CHANNEL': {
            const { channelId: channelIdToDelete } = action.payload;
            if (state.channels.length <= 1) return state;

            const newChannels = state.channels.filter(ch => ch.id !== channelIdToDelete);
            const defaultChannelId = newChannels[0].id;

            const newPresences = { ...state.presences };
            Object.values(newPresences).forEach(p => {
                if (p.channelId === channelIdToDelete) {
                    p.channelId = defaultChannelId;
                }
            });

            let newCurrentChannelIndex = state.currentChannelIndex;
            const deletedChannelIndex = state.channels.findIndex(ch => ch.id === channelIdToDelete);

            if (state.currentPresence?.channelId === channelIdToDelete) {
                newCurrentChannelIndex = 0;
            } else if (deletedChannelIndex < state.currentChannelIndex) {
                newCurrentChannelIndex -= 1;
            }
            
            localStorage.setItem('sn_channels', JSON.stringify(newChannels));

            return {
                ...state,
                channels: newChannels,
                presences: newPresences,
                currentPresence: state.currentPresence ? { ...state.currentPresence, channelId: newPresences[state.currentPresence.uid].channelId } : null,
                currentChannelIndex: newCurrentChannelIndex,
            };
        }
        case 'ADMIN_MOVE_USER': {
            const { uid: uidToMove, newChannelId } = action.payload;
            if (!state.presences[uidToMove] || !state.channels.some(ch => ch.id === newChannelId)) {
                return state;
            }
            const updatedPresence = { ...state.presences[uidToMove], channelId: newChannelId };
            return {
                ...state,
                presences: {
                    ...state.presences,
                    [uidToMove]: updatedPresence,
                },
            };
        }
        default:
            return state;
    }
};

interface AppContextType {
    state: AppState;
    dispatch: Dispatch<AppAction>;
    showToast: (message: string) => void;
    triggerCoinAnimation: (fromId: string, toId: string) => void;
    setAppStatus: (status: AppStatus) => void;
}

export const AppContext = createContext<AppContextType>({
    state: initialState,
    dispatch: () => null,
    showToast: () => {},
    triggerCoinAnimation: () => {},
    setAppStatus: () => {},
});

export const useAppContext = () => useContext(AppContext);
