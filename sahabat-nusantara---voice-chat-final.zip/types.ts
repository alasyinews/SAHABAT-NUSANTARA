export interface ModeratorPermissions {
    canKick?: boolean;
    canMove?: boolean;
    canMuteDeafen?: boolean;
    canChangeRoomMode?: boolean;
    canBan?: boolean;
}

export interface Profile {
    name: string;
    username?: string;
    address: string;
    gender: 'Perempuan' | 'Laki-laki' | 'Lainnya' | 'Tidak ditentukan';
    bio: string;
    photos: string[]; // base64 strings
    avatarIndex: number;
    coins: number;
    isVip: boolean;
    isBanned?: boolean;
    createdAt: string;
    lastLogin?: string;
    password?: string;
    moderatorRole?: 'none' | 'room' | 'global';
    managedChannelId?: string | null;
    moderatorPermissions?: ModeratorPermissions;
}

export interface User {
    uid: string;
    profile: Profile;
}

export interface Presence {
    uid:string;
    isOnline: boolean;
    channelId: string | null;
    isTalking: boolean;
    isMicMuted: boolean;
    isDeafened: boolean;
}

export interface Channel {
    id: string;
    name: string;
    mode: 'talk' | 'karaoke' | 'karaoke-reverb';
    isTemporary?: boolean;
    creatorId?: string;
    isLocked?: boolean;
}

export interface Message {
    id: string;
    senderId: string;
    text: string;
    timestamp: string;
}

export interface PrivateMessage extends Message {
    receiverId: string;
}

export interface Settings {
    theme: 'light' | 'dark';
    pttMode: 'toggle' | 'push';
}

export type AppStatus = 'loading' | 'welcome-back' | 'login' | 'profile-setup' | 'main' | 'admin-login';

export interface ModalState {
    type: 'settings' | 'room-chat' | 'private-messages' | 'user-profile' | 'edit-profile' | 'youtube' | 'coin' | 'sawer' | 'create-room' | 'admin-panel' | 'admin-edit-user' | 'confirmation' | 'admin-edit-channel' | 'admin-user-actions' | 'admin-move-user-room-select' | null;
    data?: any;
}

export interface AppState {
    currentUser: User | null;
    currentPresence: Presence | null;
    settings: Settings;
    users: Record<string, User>;
    presences: Record<string, Presence>;
    channels: Channel[];
    publicMessages: Record<string, Message[]>; // channelId -> messages
    privateMessages: Record<string, PrivateMessage[]>; // conversationId -> messages
    modal: ModalState;
    isAdmin: boolean;
    currentChannelIndex: number;
}

export type AppAction =
    | { type: 'SET_CURRENT_USER'; payload: User | null }
    | { type: 'UPDATE_CURRENT_USER_PROFILE'; payload: Partial<Profile> }
    | { type: 'SET_PRESENCE'; payload: Presence }
    | { type: 'SET_SETTINGS'; payload: Settings }
    | { type: 'ADD_USER'; payload: User }
    | { type: 'UPDATE_USER_PRESENCE'; payload: Partial<Presence> & { uid: string } }
    | { type: 'ADD_CHANNEL'; payload: Channel }
    | { type: 'SET_CHANNEL_MODE'; payload: { channelId: string; mode: 'talk' | 'karaoke' | 'karaoke-reverb' } }
    | { type: 'ADD_PUBLIC_MESSAGE'; payload: { channelId: string; message: Message } }
    | { type: 'ADD_PRIVATE_MESSAGE'; payload: { conversationId: string; message: PrivateMessage } }
    | { type: 'SHOW_MODAL'; payload: ModalState }
    | { type: 'HIDE_MODAL' }
    | { type: 'SET_ADMIN_STATUS', payload: boolean }
    | { type: 'ADMIN_UPDATE_USER_PROFILE', payload: { uid: string, data: Partial<Profile> } }
    | { type: 'SET_CURRENT_CHANNEL_INDEX'; payload: number }
    | { type: 'REORDER_CHANNELS'; payload: { startIndex: number; endIndex: number } }
    | { type: 'ADMIN_DELETE_USER'; payload: { uid: string } }
    | { type: 'ADMIN_EDIT_CHANNEL'; payload: Channel }
    | { type: 'ADMIN_DELETE_CHANNEL'; payload: { channelId: string } }
    | { type: 'ADMIN_MOVE_USER'; payload: { uid: string; newChannelId: string } };